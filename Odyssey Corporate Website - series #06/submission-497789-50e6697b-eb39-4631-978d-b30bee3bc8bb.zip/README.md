## Odyssey Corporate Website

### Prerequisites
node 12.14+
npm 6.13+

### How to run
- `npm install`
- `npm start`
- then you can view the app running at `http://localhost:3000`

### How to build for production
- `npm run build`

### Lint check
`npm run lint`

### Configuration
- The common configuration is in `src/config/index.ts`
  - `BASE_URL`, the base url of the links on the pages
  - `BASE_IMAGE_URL`, the base url of the images
  - `DATE_FORMAT`, the format of date displayed on the page
  - `LOADING_IMAGE_WAIT_TIME`, the waiting time to loading the image from server
  - `META`, meta data of the web app
  - `DataServiceId`, the setting of the different page service id
  
- package.json
  "proxy": "http://cms.dev.cynfusion.net"
  This is the proxy configuration of the endpoint base url.