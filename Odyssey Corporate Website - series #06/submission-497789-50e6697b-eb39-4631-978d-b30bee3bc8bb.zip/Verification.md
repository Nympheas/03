### Note

All the page except Article Detail page can be accessed in the primary and secondary menu.
Except the banners in Home page,New & Article page,FAQ page,
other pages are sharing the same banner components with different Drupal API data.

You can use http://localhost:3000/ to access the Home page.
You can use http://localhost:3000/about_us/news_and_articles to access the News And Articles page.
You can use http://localhost:3000/private_banking/meet_the_team to access the Private Banking - Meet the Team page.
You can use http://localhost:3000/business/business_finance to access the Bridging Finance page.
You can use http://localhost:3000/business/savings to access the Personal Savings Online ISA page.
You can use http://localhost:3000/business/relationship_finance to access the Business Relationship Manager page.
You can use http://localhost:3000/customer_suppor/faqs to access the FAQ Individual page.
You can use http://localhost:3000/about_us/article_detail/9b192d9d-3374-4037-abb1-ddea8702c2d1 to access the Article Detail page,
  you can also access the Article Detail page by clicking arrow of the "News And Articles" items in "News And Articles" page and other pages.

### BUSINESS PREMIUM CURRENT ACCOUNTS AND PERSONAL PREMIUM CURRENT ACCOUNTS

1. BANNER maps to /CurrentAccountsComponents/TopBanner components.
2. HEADER LINKS maps to /CurrentAccountsComponents/HeaderLinks component.
3. SUMMARY, TERMS & CONDITIONS, SECURE DEPOSITS sections map to the same reuseable /CurrentAccountsComponents/ImageWithLongText component.
4. QUICK LINKS (CHECK OUT OUR) maps to /CurrentAccountsComponents/QuickLinks component.
5. ELIGIBILITY CRITERIA maps to /CurrentAccountsComponents/EligibilityCriteria component.
6. OVERDRAFTS maps to /CurrentAccountsComponents/Overdrafts component.
7. APPLY ONLINE (You're nearly ready to start) maps to /CurrentAccountsComponents/ApplyOnline component.
8. FAQ (Frequently asked Questions) maps to /CurrentAccountsComponents/FAQs component.

## ABOUT US
1. BANNER section maps to /CurrentAccountsComponents/TopBanner components.
2. MESSAGE (A specialist bank serving...) section maps to /CurrentAccountsComponents/ImageWithLongText component
3. OUR CUSTOMER PROMISES section maps to /AboutUsComponents/OurCustomerPromise
4. Empowering business owners section maps to /CurrentAccountsComponents/ImageWithLongText component
5. CUSTOMER TESTIMONIALS section maps to /AboutUsComponents/CustomerTestimonials
6. FAQ (Frequently asked Questions) maps to /CurrentAccountsComponents/FAQs component.

### Test Steps
User can click on the tabs to show different News/Articles.

### Video
https://www.dropbox.com/s/0fkky7x70cxcd6j/video-integration-1.mp4?dl=0