import axios from 'axios';
import { BASE_URL, DataServiceId } from '../config';

const axiosInstance = axios.create({
  baseURL: BASE_URL,
});

// data service
export default class DataSvc {  
  // Home page 
  static async getHomeContentData() {    
    const response = await axiosInstance.get(`/jsonapi/node/cw_business_home/${DataServiceId.HomeId}?include=\
                                              field_hero_banner,field_hero_banner.field_banner_image,field_customer_interest_links,field_products,field_customer_promises,field_ads_awareness,field_trusted_provider`);
    return response.data;
  }
  
  static async getHomeBannerData(id: string) {
    const response = await axiosInstance.get(`/jsonapi/node/cw_business_home/${id}/field_hero_banner`);
    
    return response.data;
  }
  
  static async getHomeFieldQuickLinksData(id: string) {
    const response = await axiosInstance.get(`/jsonapi/paragraph/customer_interest_links/${id}/field_quick_links`);
    return response.data;
  }
  
  static async getHomeProductData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/product/${id}`,
    );

    return response.data;
  }
  
  static async getHomeFinanceData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/finance_pages/${id}`,
    );

    return response.data;
  }
  
  static async getHomeAdsAwarenessData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/ads_and_awareness/${id}`,
    );

    return response.data;
  }
  
  static async getHomeOurCustomerPromisesData(id: string) {
    const response = await axiosInstance.get(`/jsonapi/node/cw_business_home/${id}/field_customer_promises`);
    return response.data;
  }
  
  static async getHomeTrustedProviderData(id: string) {
    const response = await axiosInstance.get(`jsonapi/node/trusted_provider/${id}/field_logo_link`);
    return response.data;
  }
  
  // News and Articles page 
  static async getNewsArticlesContentData() {    
    const response = await axiosInstance.get(`/jsonapi/node/news_and_articles?include=field_media_image,field_media_image.field_media_image`);
    return response.data;
  }
  
  static async getNewsArticlesBannerData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/news_and_articles/${id}`);
    return response.data;
  }
  
  static async getNewsCategoriesData() {    
    const response = await axiosInstance.get(`/news-categories`);
    return response.data;
  }
  
  static async getNewsArticlesListData(uuid: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/news_and_articles?\
                                              page[limit]=12&include=field_media_image,field_media_image.field_media_image\
                                              &filter[field_tag_to.id][value]=${uuid}&sort=-created`);
    return response.data;
  }
  
  
  // Bridging Finance page
  static async getBridgingFinanceContentData() {    
    const response = await axiosInstance.get(`/jsonapi/node/product/${DataServiceId.BridgingFinanceId}?include=field_banner,field_header_links,field_components`);
    return response.data;
  }
  
  static async getBridgingFinanceBannerData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/product/${id}/field_banner`);
    return response.data;
  }
  
  static async getBridgingFinanceLinkIconsData(id: string) {   
    const response = await axiosInstance.get(`/jsonapi/node/product/${id}/field_header_links`);
    return response.data;
  }
  
  // Meet The Team page
  static async getMeetTheTeamContentData() {    
    const response = await axiosInstance.get(`/jsonapi/node/meet_the_team/${DataServiceId.MeetTheTeamId}?include=field_banner,field_team_members,field_client_feedback`);
    return response.data;
  }
  
  static async getMeetTheTeamBannerData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/meet_the_team/${id}/field_banner`);
    return response.data;
  }
  
  static async getMeetTheTeamTeamsData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/teams/${id}/field_members`);
    return response.data;
  }
  
  static async getMeetTheTeamCustomerFeedbackData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/meet_the_team/${id}/field_client_feedback`);
    return response.data;
  }
  
  // Personal Savings Online ISA page
  static async getPersonalSavingsOnlineISAContentData() {    
    const response = await axiosInstance.get(`/jsonapi/node/product/${DataServiceId.PersonalSavingsOnlineISAId}?include=field_banner,field_header_links,field_components`);
    return response.data;
  }
  
  static async getPersonalSavingsOnlineISABannerData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/product/${id}/field_banner`);
    return response.data;
  }
  
  static async getPersonalSavingsOnlineISALinkIconsData(id: string) {
    const response = await axiosInstance.get(`/jsonapi/node/product/${id}/field_header_links`);// '764a6bb4-62a7-4d1b-8412-97c38a96fcbc'
    return response.data;
  }
  
  
  // Business Relationship Manager page
  static async getBusinessRelationshipManagerContentData() {    
    const response = await axiosInstance.get(`/jsonapi/node/meet_the_team/${DataServiceId.BusinessRelationshipManagerId}?include=field_banner,field_team_members,field_client_feedback`);
    return response.data;
  }
  
  static async getBusinessRelationshipManagerBannerData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/meet_the_team/${id}/field_banner`);
    return response.data;
  }
  
  static async getBusinessRelationshipManagerTeamsData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/teams/${id}/field_members`);
    return response.data;
  }
  
  static async getBusinessRelationshipManagerCustomerFeedbackData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/meet_the_team/${id}/field_client_feedback`);
    return response.data;
  }
  
  // Article Detail page
  static async getArticleDetailContentData(article_uuid: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/news_and_articles/${article_uuid}?include=field_media_image,field_media_image.field_media_image,field_tag_to`);
    return response.data;
  }
  
  // FAQ Individual page
  static async getFAQIndividualContentData() {    
    const response = await axiosInstance.get(`/jsonapi/node/corporate_faq/${DataServiceId.FAQIndividualId}?include=field_faqs,field_category,field_related_faqs,field_related_items`);
    return response.data;
  }
  
  static async getFAQIndividualFAQListData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/corporate_faq/${id}/field_faqs`);
    return response.data;
  }
  
  static async getFAQIndividualRelatedFAQsData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/corporate_faq/${id}/field_related_faqs`);
    return response.data;
  }
  
  static async getFAQIndividualRelatedItemsData(id: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/corporate_faq/${id}/field_related_items`);
    return response.data;
  }  
  
  static async getBusinessCurrentAccountContentData() {
    const response = await axiosInstance.get(`jsonapi/node/business_current_account/${DataServiceId.BusinessCurrentAccountId}?include=field_compare_accounts,field_components,field_banner,field_highlighted_section,field_trusted_provider`);
    return response.data;
  }

  static async getPersonalCurrentAccountContentData() {
    const response = await axiosInstance.get(`jsonapi/node/business_current_account/${DataServiceId.PersonalCurrentAccountId}?include=field_compare_accounts,field_components,field_banner,field_highlighted_section,field_trusted_provider`);
    return response.data;
  }
  
  
  static async getBusinessCurrentAccountsContentData() {
    const response = await axiosInstance.get(
      `/jsonapi/node/product/${DataServiceId.BussinessCurrentAccountPremiumId}?include=field_header_links,field_banner,field_components`,
    );
    return response.data;
  }

  static async getPersonalCurrentAccountsContentData() {
    const response = await axiosInstance.get(
      `/jsonapi/node/product/${DataServiceId.PersonalCurrentAccountPremiumId}?include=field_header_links,field_banner,field_components`,
    );
    return response.data;
  }

  static async getCurrentAccountsBannerData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/product/${id}/field_banner`,
    );
    return response.data;
  }

  static async getCurrentAccountsHeaderLinksData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/product/${id}/field_header_links`,
    );
    return response.data;
  }

  static async getCurrentAccountsFieldComponentsData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/product/${id}/field_components`,
    );
    return response.data;
  }

  static async getCurrentAccountsCustomerInterestLinksData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/paragraph/customer_interest_links/${id}/field_quick_links`,
    );
    return response.data;
  }

  static async getCurrentAccountsFAQsData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/paragraph/faq_s/${id}/field_faqs`,
    );
    return response.data;
  }

  static async getCurrentAccountsCorporateFAQData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/corporate_faq/${id}/field_faqs`,
    );
    return response.data;
  }

  static async getCurrentAccountsCardsWithLinkTextData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/paragraph/cards_with_link_text/${id}/field_text_with_link`,
    );
    return response.data;
  }

  static async getCurrentAccountsTrustedProviderData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/paragraph/trusted_providers/${id}/field_trusted_provider`,
    );
    return response.data;
  }

  static async getCurrentAccountsTrustedProviderLogoData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/trusted_provider/${id}/field_logo_link`,
    );
    return response.data;
  }

  static async getAboutUsContentData() {
    const response = await axiosInstance.get(
      `/jsonapi/node/about_us_landing/${DataServiceId.AboutUsId}?include=field_banner,field_components,field_cw_faqs`,
    );
    return response.data;
  }

  static async getAboutUsBannerData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/about_us_landing/${id}/field_banner`,
    );
    return response.data;
  }

  static async getAboutUsFieldComponentsData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/about_us_landing/${id}/field_components`,
    );
    return response.data;
  }

  static async getAboutUsFaqsData(id: string) {
    const response = await axiosInstance.get(
      `/jsonapi/node/about_us_landing/${id}/field_cw_faqs`,
    );
    return response.data;
  }
  

  // static content data
  static async getData(url: string) {
    const response = await axiosInstance.get(url);
    return response.data;
  }
  
  static async getHeaderMenuData(parentField: string) {    
    const response = await axiosInstance.get(`/jsonapi/node/dynamic_menu?filter[field_parent]=` + parentField);
    return response.data;
  }
  
  static async getFooterData() {    
    const response = await axiosInstance.get(`/jsonapi/node/footer?include=field_footer_menu,field_trusted_providers`);
    return response.data;
  }
  
  static async getImage(imageId?: string) {
    const response = await axiosInstance.get(
      `/jsonapi/media/image/${imageId}/field_media_image`,
    );

    return response.data;
  }
  
  static async getImageVideo(imageId?: string) {
    const response = await axiosInstance.get(
      `/jsonapi/media/video/${imageId}/field_media_video_file`,
    );

    return response.data;
  }

  static async getImageBanner(imageId?: string) {
    const response = await axiosInstance.get(
      `/jsonapi/paragraph/banner/${imageId}/field_banner_image`,
    );

    return response.data;
  }

  static async getImageWithLongText(imageId?: string) {
    const response = await axiosInstance.get(
      `jsonapi/paragraph/image_with_long_text/${imageId}/field_images`,
    );

    return response.data;
  }

  static async getImageEligibilityCriteria(imageId?: string) {
    const response = await axiosInstance.get(
      `jsonapi/paragraph/eligibility_criteria/${imageId}/field_image2`,
    );

    return response.data;
  }

  static async getImage3(imageId?: string) {
    const response = await axiosInstance.get(
      `jsonapi/paragraph/card_with_image_link/${imageId}/field_image3`,
    );

    return response.data;
  }

  static async getImageDescriptionWithFaq(imageId?: string, field?: string) {
    const response = await axiosInstance.get(
      `jsonapi/paragraph/image_description_with_faq/${imageId}/${field}`,
    );

    return response.data;
  }
}
