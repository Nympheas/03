import 'babel-polyfill';
import 'whatwg-fetch';
import React, {Suspense} from 'react';
import ReactDOM from 'react-dom';
import {Provider} from 'react-redux';
import thunk from 'redux-thunk';
import {createStore, applyMiddleware} from 'redux';
import {Route, BrowserRouter} from 'react-router-dom';

import allReducers from './reducers';
import routes from './routes';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/styles.scss';
import 'accessible-nprogress/dist/accessible-nprogress.min.css';

const middlewares = [thunk];

// Only use the redux-logger middleware in development
if (process.env.NODE_ENV === 'development') {
  // middlewares.push(createLogger());
}

const store = createStore(allReducers, applyMiddleware(...middlewares));

// Helper function that renders single route
const renderRoute = (route: any, props: any) => {
  window.scrollTo(0, 0); // Reset scroll to top
  return <route.component routeParams={props.match.params} />;
};

// Helper function that create all routes
const createRoutes = () =>
  routes.map((route) => (
    <Route
      exact={true}
      key={route.path}
      path={route.path}
      component={(props: any) => renderRoute(route, props)}
    />
  ));

ReactDOM.render(
  <Suspense fallback="loading">
    <Provider store={store}>
      <BrowserRouter>
        <div>{createRoutes()}</div>
      </BrowserRouter>
    </Provider>
  </Suspense>,
  document.getElementById('root'),
);
