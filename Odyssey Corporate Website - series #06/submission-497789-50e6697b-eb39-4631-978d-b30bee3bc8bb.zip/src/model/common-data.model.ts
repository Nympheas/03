class DetailsDataModel {
  attributes: any;
  id: string = '';
  links: {
    self: any
  } = {
    self: null
  };
  relationships: any
  type: string = '';
}

export class CommonDataModel {
  data: DetailsDataModel[] = [];
  included: DetailsDataModel[] = [];
  jsonapi: {
    version: string;
    meta: any
  } = {
    version: '',
    meta: null
  };
  links: {
    self: any
  } = {
    self: null
  };
}