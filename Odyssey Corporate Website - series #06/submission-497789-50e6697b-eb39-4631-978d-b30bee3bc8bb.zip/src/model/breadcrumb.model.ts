export class BreadcrumbItemModel {
  label: string = '';
  url: string = '';
}