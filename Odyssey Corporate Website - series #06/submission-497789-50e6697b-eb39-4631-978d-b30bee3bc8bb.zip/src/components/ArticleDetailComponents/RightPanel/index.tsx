import React from 'react';
import './styles.scss';

export interface IRightPanelProps {
  dataList?: any;
}

export const RightPanel: React.FunctionComponent<IRightPanelProps> = (props) => {
  const { dataList } = props;

  return (
    <React.Fragment>
      {!!dataList && (
        <div className="section section-article-details-right-panel">
          <div className="big-title">
            {dataList.data.attributes.title}
          </div>
          <div className="content-container"
            dangerouslySetInnerHTML={{ __html: dataList.data.attributes.body.processed }}>
          </div>
          
          
          
          {true && (
            <>
            
            </>
          )}
        </div>
      )}
    </React.Fragment>
  );
};

export default RightPanel;
