import React, { useState, useEffect } from 'react';
import dataSvc from '../../../services/dataSvc';
import { BASE_IMAGE_URL } from '../../../config';
import { CommonDataModel } from '../../../model/common-data.model';
import './styles.scss';

export interface ITopBannerProps {
  noMask?: boolean;
  dataList: CommonDataModel;
}

export const TopBanner: React.FunctionComponent<ITopBannerProps> = (props) => {
  const { noMask, dataList } = props;
  
  const [imageUrl, setImageUrl] = useState<string>('');
  
  useEffect(() => {
    if (props.dataList) { 
      // console.log(dataList.data[0].attributes)
      
      if (dataList.data.length > 0) {
        let imageUrlTemp = '';
        dataSvc.getImage(dataList.data[0].relationships.field_banner_image.data.id).then((data) => {
          // load data          
          imageUrlTemp = BASE_IMAGE_URL + data.data.attributes.uri.url;
          
          setImageUrl(imageUrlTemp);
        })
      }
    }
    // eslint-disable-next-line
  }, [props.dataList]);
  
  // get Image Cover Class
  const getImageCoverClass = (field_masking_on_image: string) => {
    switch (field_masking_on_image) {
      case 'Main Hero':
        return 'main-hero';
      case 'Grey Curve':
        return 'grey-curve';
      case 'Teal Curve':
        return 'teal-curve';
      case 'Pink Curve':
        return 'pink-curve';
      default:
        return '';
    }
  };
  
  // get Image Cover Position
  const getImageCoverPosition = (field_masking_position: string) => {
    switch (field_masking_position) {
      case 'Left Bottom':
        return 'position-left-bottom';
      case 'Right Top':
        return 'position-right-top';
      default:
        return '';
    }
  };
  
  // get Banner Image Style
  const getBannerImageStyle = () => {
    const bannerImageUrl = imageUrl ? imageUrl : '';
    const str = `url(${bannerImageUrl}) center center no-repeat`;
    
    return str ;
  };

  return (
    <React.Fragment>
      {imageUrl !== '' && (
        <div className="section section-home-banner"
          style={{background: getBannerImageStyle(), backgroundSize: 'cover'}}>
          <div className="container">
            {
              dataList.data.map((item, index) => (
                <React.Fragment key={index}>
                  {!noMask && (
                    <div
                      className={`image-cover ${getImageCoverClass(item.attributes.field_masking_on_image)}`}>
                    </div>
                  )}
                  <div className={`hero-business-content ${getImageCoverPosition(item.attributes.field_masking_position)}`}>
                    <div className="big-txt"
                      dangerouslySetInnerHTML={{ __html: item.attributes.field_formatted_heading.processed }}>
                    </div>
                    <div className="bottom-btn">
                      <a
                        href="#javascript"
                        className="btn btn-black">Find Out More</a>
                    </div>
                  </div>
                </React.Fragment>
              ))
            }
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default TopBanner;
