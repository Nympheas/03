import React, {useEffect, useState} from 'react';
import { NavLink } from 'react-router-dom';
import { CommonDataModel } from '../../../model/common-data.model';
import { DATE_FORMAT } from '../../../config';
import moment from 'moment';
import * as _ from 'lodash';
import './styles.scss';

export interface INewsArticlesListProps {
  dataList: CommonDataModel;
}

export const NewsArticlesList: React.FunctionComponent<INewsArticlesListProps> = (props) => {
  const [dataList, setDataList] = useState<any>(props.dataList);
  
  useEffect(() => {
    if (props.dataList) {
      const dataListTemp = _.cloneDeep(props.dataList);
      dataListTemp.data = dataListTemp.data.slice(0, 6);
      
      setDataList(rearrangeItems(dataListTemp));
    }
  }, [props.dataList]);
  
  /**
   * rearrange Items
   * @param dataList The data that to be rearranged
   */
  const rearrangeItems = (dataList: any) => {
    const dataListTemp = dataList;
    
    return dataListTemp;
  };
  
  /**
   * get Items
   * @param rowIndex The index of row
   * @param columnIndex The index of column in the row
   * @param columnSubRowIndex The index of sub row of column in the row
   */
  const getItems = (rowIndex: number, columnIndex: number, columnSubRowIndex: number) => {
    const item = dataList.data.slice(0 + 6 * rowIndex, 6 + 6 * rowIndex).slice(0 + 2 * columnIndex, 2 + 2 * columnIndex)[columnSubRowIndex];
    
    return item;
  };
  
  // get Color Class
  const getColorClass = () => {
    const index = Math.floor(Math.random() * 3);
    const classArray = ['light-green', 'black-bg', 'ligth-blue'];
    
    return classArray[index];
  };

  return (
    <div className="section-news-and-articles">
      <div className="container">
        <div className="new-and-articles">
          <div className="top-title center">
            News And Articles
          </div>
          {
            (new Array(Math.ceil(dataList.data.length / 6)).fill('')).map((rowItem, rowIndex) => (
              <div className="row" key={rowIndex}>
                {
                  (new Array(Math.ceil(dataList.data.slice(0 + 6 * rowIndex, 6 + 6 * rowIndex).length / 2)).fill('')).map((columnItem, columnIndex) => (
                    <div className="col col-md-4 general-middle-content" key={columnIndex}>
                      {
                        (new Array(Math.ceil(dataList.data.slice(0 + 6 * rowIndex, 6 + 6 * rowIndex).slice(0 + 2 * columnIndex, 2 + 2 * columnIndex).length)).fill('')).map((columnSubRowItem, columnSubRowIndex) => (
                          <div className={`general-content ${getColorClass()}`} key={columnSubRowIndex}>
                            <h3>
                              {getItems(rowIndex, columnIndex, columnSubRowIndex)?.attributes.title}
                            </h3>
                            <div className="greneral-content-action">
                              <p className="left-txt">{moment(getItems(rowIndex, columnIndex, columnSubRowIndex)?.attributes.changed).format(DATE_FORMAT)}</p>
                              <NavLink to={`/about_us/article_detail/${getItems(rowIndex, columnIndex, columnSubRowIndex)?.id}`}
                                className="icons icon-circle-arrow-right">
                                &nbsp;
                              </NavLink>
                            </div>
                          </div>
                        ))
                      }
                    </div>
                  ))
                }
              </div>
            ))
          }
          <div className="bottom-btn">
            <NavLink to='/about_us/news_and_articles' className="btn btn-green-border">
              View All News & Articles
            </NavLink>
          </div>
        </div>
        {/* end .new-and-articles */}
      </div>
    </div>
  );
};

export default NewsArticlesList;
