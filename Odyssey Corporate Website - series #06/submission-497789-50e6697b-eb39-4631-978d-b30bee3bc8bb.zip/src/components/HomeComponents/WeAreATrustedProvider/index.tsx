import React, { useState, useEffect } from 'react';
import dataSvc from '../../../services/dataSvc';
import { BASE_IMAGE_URL } from '../../../config';
import './styles.scss';

export interface IWeAreATrustedProviderProps {
  dataList: any;
}

export const WeAreATrustedProvider: React.FunctionComponent<IWeAreATrustedProviderProps> = (props) => {
  const { dataList } = props;
  
  const [imageArray, setImageArray] = useState<string[]>([]);
  
  useEffect(() => {
    if (props.dataList) {
      const fetchImages = async () => {
        const imageArrayTemp: string[] = [];
        await Promise.all(
          props.dataList.data.map(async (item: any) => {
            let response = await dataSvc.getImage(item.relationships.field_media_logo.data.id)
            imageArrayTemp.push(BASE_IMAGE_URL + response.data.attributes.uri.url)
          })
        )
        setImageArray(imageArrayTemp);
      }
      fetchImages().then(r => {});
    }
  }, [props.dataList]);
  
  return (
    <div className="section-we-are-a-trusted-provider">
      <div className="container">
        <div className="gray-title center">We Are A Trusted Provider</div>
        <div className="logos-list">
          <ul className="flex-grid">
            {
              !!dataList && dataList.data.map((item: any, index: number) => (
              <li key={index}>
                {!!imageArray[index] && (
                <div className="logo">
                  <img src={imageArray[index]} alt="logo" />
                </div>
                )}
              </li>
            ))
            }
          </ul>
        </div>
      </div>
    </div>
  );
};

export default WeAreATrustedProvider;
