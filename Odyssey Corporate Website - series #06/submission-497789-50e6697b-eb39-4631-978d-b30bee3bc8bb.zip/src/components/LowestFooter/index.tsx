import React from 'react';
import './styles.scss';

export interface ILowestFooterProps {
}

export const LowestFooter: React.FunctionComponent<ILowestFooterProps> = (props) => {

  return (
    <div className="footer-bottom">
      <div className="footer-bottom-content">
        <div className="footer-bottom-description">
          <p>Odyssey Bank Limited. Registered in England and Wales: 04728421. Registration Office: 27-31 Charlotte Street, London W1T 1RP. Correspondence address: PO Box 17484, 87 Chase Side, London N14 5WH.</p>
          <p>Odyssey Bank Limited is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. Our main business is the provision of financial services under registration number no. 575105.</p>
          <p>Eligible deposits with Odyssey Bank Limited are protected up to a total of £85,000 by the Financial Services Compensation Scheme, the UK's deposit guarantee scheme. Any deposits you hold above the protected limit are unlikely to be covered. Further information is available <a href="#javascript"><strong>here</strong></a> or visit <a href="#javascript"><strong>https://www.fscs.org.uk/</strong><i className="icons icon-link"></i></a></p>
          <p><a href="#javascript"><strong>Click here</strong></a> for free and impartial advice, set up by the government. Odyssey Bank Limited is a member of UK Finance and subscribes to the Standards of Lending Practice published by the Lending Standards Board which covers good practice in relation to loans, overdrafts and other types of lending that we do not currently offer. Further information is available <a href="#javascript"><strong>here.</strong></a></p>
          <p>Calls to 0345 850 5555 (+44 (0)20 3375 6422 from outside the UK) may be recorded for monitoring and training. </p>
        </div>
        <div className="footer-bottom-award flex">
          <img src="/assets/logos/footer-award-1.png" alt="Award" />
          <img src="/assets/logos/footer-award-2.png" alt="Award" />
          <img src="/assets/logos/footer-award-3.png" alt="Award" />
          <img src="/assets/logos/footer-award-4.png" alt="Award" />
          <img src="/assets/logos/footer-award-5.png" alt="Award" />
        </div>
      </div>
      <div className="footer-bottom-action">
        <div className="footer-bottom-action-download">
          <h5>DOWNLOAD OUR APP</h5>
          <div className="logos">
            <a href="#javascript" className="logo">
              <img src="/assets/logos/download-playstore-black.svg" alt="Download" />
            </a>
            <a href="#javascript" className="logo">
              <img src="/assets/logos/download-appstore-black.svg" alt="Download" />
            </a>
          </div>
        </div>
        <div className="footer-bottom-action-social">
          <h5>Connect with us</h5>
          <div className="logos">
            <a href="#javascript" className="logo">
              <i className="icons icon-phone-black"></i>
            </a>
            <a href="#javascript" className="logo">
              <i className="icons icon-message-black"></i>
            </a>
            <a href="#javascript" className="logo">
              <i className="icons icon-linkedin-black"></i>
            </a>
            <a href="#javascript" className="logo">
              <i className="icons icon-twitter-black"></i>
            </a>
            <a href="#javascript" className="logo">
              <i className="icons icon-instagram-black"></i>
            </a>
          </div>
          
          <a
            href="#javascript"
            className="btn btn-black">Modern Slavery Statement</a>
        </div>
      </div>
    </div>
  );
};

export default LowestFooter;
