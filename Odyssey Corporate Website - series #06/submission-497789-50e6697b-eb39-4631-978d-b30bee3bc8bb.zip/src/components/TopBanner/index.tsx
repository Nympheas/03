import React, { useState, useEffect } from 'react';
import dataSvc from '../../services/dataSvc';
import { BASE_IMAGE_URL } from '../../config';
import './styles.scss';

export interface ITopBannerProps {
  noMask?: boolean;
  dataList?: any;
}

export const TopBanner: React.FunctionComponent<ITopBannerProps> = (props) => {
  const { noMask, dataList } = props;
  
  const [imageUrl, setImageUrl] = useState<string>('/assets/home-banner.jpg');
  
  useEffect(() => {
    if (props.dataList) {  
      // console.log(dataList.data.attributes)
    
      let imageUrlTemp = '';
      let imageId = '';
      if (dataList.data.relationships.field_banner_image) {
        imageId = dataList.data.relationships.field_banner_image.data.id;
      } else if (dataList.data.relationships.field_media_image.data) {
        imageId = dataList.data.relationships.field_media_image.data.id;
      }
      
      dataSvc.getImage(imageId).then((data) => {
        // load data          
        imageUrlTemp = BASE_IMAGE_URL + data.data.attributes.uri.url;
        
        setImageUrl(imageUrlTemp);
      })
    }
    // eslint-disable-next-line
  }, [props.dataList]);
  
  // get Image Cover Class
  const getImageCoverClass = (field_masking_on_image: string) => {
    switch (field_masking_on_image) {
      case 'Main Hero':
        return 'main-hero';
      case 'Grey Curve':
        return 'grey-curve';
      case 'Teal Curve':
        return 'teal-curve';
      case 'Pink Curve':
        return 'pink-curve';
      default:
        return '';
    }
  };
  
  // get Image Cover Position
  const getImageCoverPosition = (field_masking_position: string) => {
    switch (field_masking_position) {
      case 'Left Bottom':
        return 'position-left-bottom';
      case 'Right Top':
        return 'position-right-top';
      default:
        return '';
    }
  };
  
  // get Banner Image Style
  const getBannerImageStyle = () => {
    const bannerImageUrl = imageUrl ? imageUrl : '';
    const str = `url(${bannerImageUrl}) center center no-repeat`;
    
    return str ;
  };

  return (
    <React.Fragment>
      <div className="section section-bridging-banner "
        style={{background: getBannerImageStyle(), backgroundSize: 'cover'}}>
        {!noMask && (
          <div
            className={`image-cover ${getImageCoverClass(dataList.data.attributes.field_masking_on_image)}`}>
          </div>
        )}
        <div className="container">
          <div className={`hero-business-content ${getImageCoverPosition(dataList.data.attributes.field_masking_position)}`}>
	        <div className="big-txt"
              dangerouslySetInnerHTML={{ __html: dataList.data.attributes.field_title }}>
            </div>
            <div className="sub-txt"
              dangerouslySetInnerHTML={{ __html: dataList.data.attributes.field_subtitle }}>
            </div>
            {!!dataList.data.attributes.field_cta_button_link && (
              <div className="bottom-btn">
                <a
                  href={dataList.data.attributes.field_cta_button_link.uri}
                  className="btn btn-black">
                  {dataList.data.attributes.field_cta_button_link.title}
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default TopBanner;
