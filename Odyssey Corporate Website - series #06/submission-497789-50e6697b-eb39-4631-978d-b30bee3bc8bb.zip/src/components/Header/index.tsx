import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { CommonDataModel } from '../../model/common-data.model';
import './styles.scss';

export interface IHeaderProps {
  activeMenu: string;
  dataList: CommonDataModel;
}

export const Header: React.FunctionComponent<IHeaderProps> = (props) => {
  const { activeMenu, dataList } = props;
  const [hoverOnBusinessCurrentAccount, setHoverOnBusinessCurrentAccount] = useState<boolean>(false);
  const [hoverOnPersonalCurrentAccount, setHoverOnPersonalCurrentAccount] = useState<boolean>(false);
  
  // mouse Enter
  const mouseEnter = (hoveredItemName: string) => {
    if (activeMenu === 'Business') {
      if (hoveredItemName === 'Current Accounts') {
        setHoverOnBusinessCurrentAccount(true);
      }
    }
    
    if (activeMenu === 'Personal') {
      if (hoveredItemName === 'Current Accounts') {
        setHoverOnPersonalCurrentAccount(true);
      }
    }
  };
  
  // mouse Leave
  const mouseLeave = () => {
    setHoverOnBusinessCurrentAccount(false);
    setHoverOnPersonalCurrentAccount(false);
  };
  
  // is Show Current Account Popup
  const isShowCurrentAccountPopup = () => {
    let returnValue = '';
    
    if (activeMenu === 'Business' && hoverOnBusinessCurrentAccount) {
      returnValue = 'Business';
    }
    
    if (activeMenu === 'Personal' && hoverOnPersonalCurrentAccount) {
      returnValue = 'Personal';
    }
    
    return returnValue;
  };
  
  return (
    <header className="header ">
      <div className="nav-bar-mini flex-grid">
        <div className="container flex-grid">
          <div className="lefts flex">
            <div className="header-nav">
              <ul className="flex">
                <li>
                  <NavLink to='/'
                    className={`tab-items ${activeMenu === 'Business' ? 'current' : ''}`}>
                    Business
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/private_banking/meet_the_team"
                    className={`tab-items ${activeMenu === 'Private Banking' ? 'current' : ''}`}>
                    Private Banking
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/personal/current_account"
                    className={`tab-items ${activeMenu === 'Personal' ? 'current' : ''}`}>
                    Personal
                  </NavLink>
                </li>
                <li>
                  <NavLink to='/about_us/cynergybank'
                    className={`tab-items ${activeMenu === 'About Us' ? 'current' : ''}`}>
                    About Us
                  </NavLink>
                </li>
                <li>
                  <NavLink to='/customer_suppor/faqs'
                    className={`tab-items ${activeMenu === 'Customer Support' ? 'current' : ''}`}>
                    Customer Support
                  </NavLink>
                </li>
              </ul>
            </div>
          </div>
          <div className="rights flex">
            <div className="search-module">
              <a href="#javascript" className="icons btn-search">&nbsp;</a>
            </div>
            <a href="#javascript" className="btn btn-green">Log in</a>
          </div>
        </div>
      </div>
      <div className="nav-bar">
        <div className="container flex">
          <div className="logo-area">
            <img src="/assets/logos/oddysey.svg" alt="Oddysey" />
          </div>
          <div className="header-nav">
            <ul className="flex">
              {
                (dataList?.data).map((item: any, index: number) => (
                  <li key={index}>
                    <NavLink to={`${item.attributes.field_url.uri.replace('internal:', '')}`}
                      className={`tab-items`}
                      activeClassName="current"
                      exact={activeMenu !== 'About Us' ? true : false}
		      onMouseEnter={() => {
                        mouseEnter(item.attributes.title)
                      }}
                      onMouseLeave={() => {
                        mouseLeave()
                      }}
                      onClick={(event) => {
                      }}>
                      {item.attributes.title}
                    </NavLink>
                  </li>
                ))
              }
            </ul>
          </div>
          <div className="desktop-hide mobile-show">
              <a href="#javascript" className="icons icon-search">&nbsp;</a>
              <a href="#javascript" className="btn btn-green">Log in</a>
              <a href="#javascript" className="icons icon-nav">&nbsp;</a>
          </div>
        </div>
      </div>
      {isShowCurrentAccountPopup() === 'Business' && (
        <div className="two-items-popup"
          onMouseEnter={() => {
            mouseEnter('Current Accounts')
          }}
          onMouseLeave={() => {
            mouseLeave()
          }}>
          <div className="container">
            <NavLink to="/business/current_accounts" className="items">
              <div className="green-point">C</div>
              <div className="right-area">
                <span className="blue-title">
                  Classic Business Account
                </span>
                <p className="txt">
                  A Business Classic Account with Odyssey 
                  Bank gives you everything you need to 
                  keep your business in order. 
                </p>
              </div>
            </NavLink>
            <div className="border-line"></div>
            <NavLink to="/business/current_accounts_premium" className="items">
              <div className="green-point">P</div>
              <div className="right-area">
                <span className="blue-title">
                  Premium Business Account
                </span>
                <p className="txt">
                  A Business Premium Account with Odyssey 
                  Bank gives you everything you need to 
                  keep your business in order. 
                </p>
              </div>
            </NavLink>
          </div>
        </div>
      )}
      {isShowCurrentAccountPopup() === 'Personal' && (
        <div className="two-items-popup"
          onMouseEnter={() => {
            mouseEnter('Current Accounts')
          }}
          onMouseLeave={() => {
            mouseLeave()
          }}>
          <div className="container">
            <NavLink to="/personal/current_account" className="items">
              <div className="green-point">C</div>
              <div className="right-area">
                <span className="blue-title">
                  Classic Personal Account
                </span>
                <p className="txt">
                  A Personal Classic Account with Odyssey 
                  Bank gives you everything you need to 
                  keep your business in order. 
                </p>
              </div>
            </NavLink>
            <div className="border-line"></div>
            <NavLink to="/personal/current_account_premium" className="items">
              <div className="green-point">P</div>
              <div className="right-area">
                <span className="blue-title">
                  Premium Personal Account
                </span>
                <p className="txt">
                  A Personal Premium Account with Odyssey 
                  Bank gives you everything you need to 
                  keep your business in order. 
                </p>
              </div>
            </NavLink>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
