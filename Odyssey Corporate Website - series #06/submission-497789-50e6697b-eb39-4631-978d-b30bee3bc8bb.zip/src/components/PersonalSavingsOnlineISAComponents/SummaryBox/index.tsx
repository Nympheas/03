import React, { useState, useEffect } from 'react';
import dataSvc from '../../../services/dataSvc';
import './styles.scss';

export interface ISummaryBoxProps {
  dataList?: any;
}

export const SummaryBox: React.FunctionComponent<ISummaryBoxProps> = (props) => {
  const [content, setContent] = useState<any>();
  
  useEffect(() => {
    if (props.dataList) {      
      dataSvc.getData(props.dataList).then((data) => {        
        const url = data.data.relationships.field_summeries.links.related.href.replace('http://cms.dev.cynfusion.net/', '');
        dataSvc.getData(url).then((summaryData) => {
          setContent(summaryData.data);
        });
      });
    }
    // eslint-disable-next-line
  }, [props.dataList]);

  return (
    <React.Fragment>
      {!!content && (
        <div className="section section-personal-savings-online-isa-summary-box">
          <div className="title-full">SUMMARY BOX</div>
          
          {
            content.map((item: any, index: number) => (
              <div className="con-box" key={index}>
                <div className="title">
                  {item.attributes.field_title}
                </div>
                <div dangerouslySetInnerHTML={{ __html: item.attributes.field_text.processed }}>
                </div>
              </div>
            ))
          }
	  
        </div>
      )}
    </React.Fragment>
  );
};

export default SummaryBox;
