import React, { useState, useEffect } from 'react';
import dataSvc from '../../../services/dataSvc';
import './styles.scss';

export interface IYouAreNearlyReadyToStartProps {
  dataList?: any;
}

export const YouAreNearlyReadyToStart: React.FunctionComponent<IYouAreNearlyReadyToStartProps> = (props) => {
  const [content, setContent] = useState<any>();
  
  const [itemArray, setItemArray] = useState<any[]>([]);
  
  useEffect(() => {
    if (props.dataList) {
      dataSvc.getData(props.dataList).then((data) => {
        setContent(data);
        
        const url = data.data.relationships.field_text_with_link.links.related.href.replace('http://cms.dev.cynfusion.net/', '');
        dataSvc.getData(url).then((itemData) => {
          setItemArray(itemData.data);
        });
      });
    }
    // eslint-disable-next-line
  }, [props.dataList]);

  return (
    <React.Fragment>
      {!!content && (
      <div className="section section-personal-savings-online-isa-you-are-nearly-ready-to-start"
        style={{backgroundColor: content.data.attributes.field_background_color}}>
          <div className="content-container"
            dangerouslySetInnerHTML={{ __html: content.data.attributes.field_heading }}>
          </div>
          <div className="flex-space w-916">
            {
              itemArray.length > 0 && itemArray.map((item, index) => (
                <div className="isa-box" key={index}>
                  <div className="sm-tit">{item.attributes.field_title}</div>
                  <div className="txt-p"
                    dangerouslySetInnerHTML={{ __html: item.attributes.field_text.value }}>
                  </div>
                  {
                    item.attributes.field_links.map((linkItem: any, linkIndex: number) => (
                      <div className="btn-black" key={linkIndex}>
                        <a href={linkItem.uri}>{linkItem.title}</a>
                      </div>
                    ))
                  }
                </div>
              ))
            }
          </div>
      </div>
      )}
    </React.Fragment>
  );
};

export default YouAreNearlyReadyToStart;
