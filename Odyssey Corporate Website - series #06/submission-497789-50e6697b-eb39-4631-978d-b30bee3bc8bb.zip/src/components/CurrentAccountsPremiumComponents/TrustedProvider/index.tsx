import React, { useEffect, useState } from 'react';
import { BASE_IMAGE_URL } from '../../../config';
import dataSvc from '../../../services/dataSvc';
import './styles.scss';

interface ITrustedProviderProps {
  dataList: any;
  type?: string;
}

const TrustedProvider: React.FunctionComponent<ITrustedProviderProps> = (
  props,
) => {
  const { dataList, type } = props;
  const [dataTrustedProvider, setDataTrustedProvider] = useState<any>();
  const [imageArray, setImageArray] = useState<string[]>([]);

  useEffect(() => {
    dataSvc.getCurrentAccountsTrustedProviderData(dataList.id).then((data) => {
      setDataTrustedProvider(data);
      dataSvc
        .getCurrentAccountsTrustedProviderLogoData(data.data.id)
        .then((dataTrusted) => {
          const fetchImages = async () => {
            const imageArrayTemp: string[] = [];
            await Promise.all(
              dataTrusted.data.map(async (item: any) => {
                let response = await dataSvc.getImage(item.relationships.field_media_logo.data.id)
                imageArrayTemp.push(BASE_IMAGE_URL + response.data.attributes.uri.url)
              })
            )
            setImageArray(imageArrayTemp);
          }
          fetchImages().then(r => {});
        });
    });
  }, [dataList]);

  return (
    <div
      className={`section-trusted-provider ${
        type === 'personal' ? 'personal-trusted-provider' : ''
      }`}>
      <div className="container">
        <div className="trusted-provider-content">
          <div className="left-content">
            <h2 className="title">
              {!!dataTrustedProvider &&
                dataTrustedProvider.data.attributes.title}
            </h2>
            <div
              className="txt"
              dangerouslySetInnerHTML={{
                __html:
                  !!dataTrustedProvider &&
                  dataTrustedProvider.data.attributes.body.value,
              }}></div>
          </div>
          <div className="right-content">
            <ul className="flex-grid">
              {!!imageArray &&
                imageArray.map((item: any, index: number) => (
                  <li key={index}>
                    <div className="logo">
                      <img src={item} alt="logo" />
                    </div>
                  </li>
                ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrustedProvider;
