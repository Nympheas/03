import React, { useState } from 'react';
import './styles.scss';

interface IFAQItemProps {
  dataList: any;
  isSignle?: boolean;
}

const FAQItem: React.FunctionComponent<IFAQItemProps> = (props) => {
  const { dataList, isSignle } = props;
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  return (
    <div
      className={`item-current-accounts-faq ${isExpanded ? 'expanded' : ''} ${
        isSignle ? 'single' : ''
      }`}>
      <div className="top-title" onClick={() => setIsExpanded(!isExpanded)}>
        <h4>{dataList.attributes.field_title}</h4>
        <i className="icons icon-arrow"></i>
      </div>
      <div className="bottom-content">
        <div
          className="content"
          dangerouslySetInnerHTML={{
            __html: dataList.attributes.field_text.value,
          }}></div>
      </div>
    </div>
  );
};

export default FAQItem;
