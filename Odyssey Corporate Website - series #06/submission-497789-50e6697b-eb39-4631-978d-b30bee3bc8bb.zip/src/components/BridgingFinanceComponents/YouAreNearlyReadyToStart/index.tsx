import React, { useState, useEffect } from 'react';
import dataSvc from '../../../services/dataSvc';
import './styles.scss';

export interface IYouAreNearlyReadyToStartProps {
  dataList?: any;
}

export const YouAreNearlyReadyToStart: React.FunctionComponent<IYouAreNearlyReadyToStartProps> = (props) => {
  const [content, setContent] = useState<any>();
  
  useEffect(() => {
    if (props.dataList) {      
      dataSvc.getData(props.dataList).then((data) => {
        setContent(data);
      });
    }
    // eslint-disable-next-line
  }, [props.dataList]);

  return (
    <React.Fragment>
      {!!content && (
        <div className="section section-bridging-finance-you-are-nearly-ready-to-start"
          style={{backgroundColor: content.data.attributes.field_background_color}}>
          <div className="content-container"
            dangerouslySetInnerHTML={{ __html: content.data.attributes.field_text.processed }}>
          </div>
          {content.data.attributes.field_link && (
            <div className="btn-black">
              <a href={content.data.attributes.field_link.uri}>
                {content.data.attributes.field_link.title}
              </a>
            </div>
          )}
        </div>
      )}
    </React.Fragment>
  );
};

export default YouAreNearlyReadyToStart;
