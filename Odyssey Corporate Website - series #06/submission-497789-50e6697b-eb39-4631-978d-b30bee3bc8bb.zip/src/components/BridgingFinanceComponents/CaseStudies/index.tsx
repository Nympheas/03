import React, { useState, useEffect } from 'react';
import dataSvc from '../../../services/dataSvc';
import { DATE_FORMAT, BASE_IMAGE_URL, LOADING_IMAGE_WAIT_TIME } from '../../../config';
import moment from 'moment';
import './styles.scss';

export interface ICaseStudiesProps {
  dataList?: any;
}

export const CaseStudies: React.FunctionComponent<ICaseStudiesProps> = (props) => {
  const [content, setContent] = useState<any>();
  
  const [imageArray, setImageArray] = useState<string[]>([]);
  const [articleArray, setArticleArray] = useState<any[]>([]);
  
  useEffect(() => {
    if (props.dataList) {
      
      dataSvc.getData(props.dataList).then((data) => {
        setContent(data);

        const imageArrayTemp: string[] = [];
        const articleArrayTemp: any[] = [];
        data.data.relationships.field_case_studies.data.forEach((articleItem: any, articleIndex: number) => {
          setTimeout( () => {
            dataSvc.getArticleDetailContentData(articleItem.id).then((articleData) => {
              // load data          
              articleArrayTemp.push(articleData);
              
              setTimeout( () => {
                dataSvc.getImage(articleData.data.relationships.field_media_image.data.id).then((imageData) => {
                  // load data          
                  imageArrayTemp.push(BASE_IMAGE_URL + imageData.data.attributes.uri.url);
                })
              }, LOADING_IMAGE_WAIT_TIME * articleIndex * 2);
            });
          }, LOADING_IMAGE_WAIT_TIME * articleIndex);
        });
        
        setTimeout( () => {
          setArticleArray(articleArrayTemp);
        }, LOADING_IMAGE_WAIT_TIME * (data.data.relationships.field_case_studies.data.length + 1));
        
        setTimeout( () => {
          setImageArray(imageArrayTemp);
        }, LOADING_IMAGE_WAIT_TIME * (data.data.relationships.field_case_studies.data.length + 1) * 2);
      });
    }
    // eslint-disable-next-line
  }, [props.dataList]);

  return (
    <React.Fragment>
      {!!content && (
      <div className="section section-bridging-finance-case-studies">
        <div className="flex-space">
          <div className="txt-box">
            <div className="margin">
              <div className="title">
                {content.data.attributes.field_heading}
              </div>
              {content.data.attributes.field_text && (
                <div className="txt">
                  <p dangerouslySetInnerHTML={{ __html: content.data.attributes.field_text }}>
                  </p>
                </div>
              )}
	          <div className="txt">
                <p>
                  We're thrilled to work closely with 
                  our customers providing them 
                  with loans and responsive teams 
                  that support their growth.
                </p>
              </div>
              <div className="btn-border">
                <a href="#javascript">See all Case Studies</a>
              </div>
            </div>
          </div>
          {
            articleArray.map((item, index) => (
              <div className="cards" key={index}>
                <div className="margin">
                  <div className="pic">
                    <img src={imageArray[index]} alt="img" />
                  </div>
                  <div className="main  bg-darkblue">
                    <div className="sm-tit color-white">
                      {item.data.attributes.title}
                    </div>
                    <div className="date">{moment(item.data.attributes.created).format(DATE_FORMAT)}</div>
                  </div>
                </div>
              </div>
            ))
          }
          <div className="mobile-btn">
            <a href="#javascript">View All Case Studies</a>
          </div>
        </div>
      </div>
      )}
    </React.Fragment>
  );
};

export default CaseStudies;
