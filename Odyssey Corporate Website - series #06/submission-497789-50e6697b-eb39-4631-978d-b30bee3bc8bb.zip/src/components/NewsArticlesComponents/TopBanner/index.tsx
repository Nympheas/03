import React, { useState, useEffect } from 'react';
import dataSvc from '../../../services/dataSvc';
import { DATE_FORMAT, BASE_IMAGE_URL } from '../../../config';
import moment from 'moment';
import './styles.scss';

export interface ITopBannerProps {
  noMask?: boolean;
  dataList: any;
}

export const TopBanner: React.FunctionComponent<ITopBannerProps> = (props) => {
  const { noMask, dataList } = props;
  
  const [imageUrl, setImageUrl] = useState<string>('');
  
  useEffect(() => {
    if (props.dataList) {
      // console.log(dataList.data.attributes)
       
      let imageUrlTemp = '';
      dataSvc.getImage(dataList.data.relationships.field_media_image.data.id).then((data) => {
        // load data          
        imageUrlTemp = BASE_IMAGE_URL + data.data.attributes.uri.url;
        
        setImageUrl(imageUrlTemp);
      })
    }
    // eslint-disable-next-line
  }, [props.dataList]);
  
  // get Image Cover Class
  const getImageCoverClass = (field_masking_on_image: string) => {
    switch (field_masking_on_image) {
      case 'Main Hero':
        return 'main-hero';
      case 'Grey Curve':
        return 'grey-curve';
      case 'Teal Curve':
        return 'teal-curve';
      case 'Pink Curve':
        return 'pink-curve';
      default:
        return '';
    }
  };
  
  // get Image Cover Position
  const getImageCoverPosition = (field_masking_position: string) => {
    switch (field_masking_position) {
      case 'Left Bottom':
        return 'position-left-bottom';
      case 'Right Top':
        return 'position-right-top';
      default:
        return '';
    }
  };
  
  // get Banner Image Style
  const getBannerImageStyle = () => {
    const bannerImageUrl = imageUrl ? imageUrl : '';
    const str = `url(${bannerImageUrl}) center center no-repeat`;
    
    return str ;
  };

  return (
    <React.Fragment>
      {imageUrl !== '' && (
        <div className="section section-articles-banner"
          style={{background: getBannerImageStyle(), backgroundSize: 'cover'}}>
          {!noMask && (
            <div
              className={`image-cover ${getImageCoverClass(dataList.data.attributes.field_masking_on_image)}`}>
            </div>
          )}
          <div className="container">
            <div className={`hero-business-content ${getImageCoverPosition(dataList.data.attributes.field_masking_position)}`}>
              <div className="date-txt">
                {moment(dataList.data.attributes.created).format(DATE_FORMAT)}
              </div>
              <div className="white-big-txt">
                {dataList.data.attributes.title}
              </div>
              <div className="bank-txt"
                dangerouslySetInnerHTML={{ __html: dataList.data.attributes.body.value }}>
              </div>
              <div className="bottom-btn">
                <a
                  href="#javascript"
                  className="btn btn-black">Read Article</a>
              </div>
            </div>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default TopBanner;
