import React, {useEffect, useState} from 'react';
import { NavLink } from 'react-router-dom';
import { CommonDataModel } from '../../../model/common-data.model';
import { DATE_FORMAT } from '../../../config';
import moment from 'moment';
import './styles.scss';

export interface INewsArticlesListProps {
  dataList: CommonDataModel;
}

export const NewsArticlesList: React.FunctionComponent<INewsArticlesListProps> = (props) => {
  const [dataList, setDataList] = useState<any>(props.dataList);
  const [maxNumberRow, setMaxNumberRow] = useState<number>(0);
  
  useEffect(() => {
    if (props.dataList) {
      setDataList(rearrangeItems(props.dataList));
    }
  }, [props.dataList]);
  
  /**
   * rearrange Items
   * @param dataList The data that to be rearranged
   */
  const rearrangeItems = (dataList: any) => {
    const dataListTemp = dataList;
    
    let hasImagesNumber = 0;
    dataListTemp.data.forEach((item: any, index: number) => {
      if (item.attributes.field_display_image !== null) {
        hasImagesNumber++;
      }
    });
    
    if (hasImagesNumber === dataListTemp.data.length) {
      setMaxNumberRow(6);
    }
    
    if (hasImagesNumber === 0) {
      setMaxNumberRow(12);
    }
    
    return dataListTemp;
  };
  
  /**
   * get Items
   * @param rowIndex The index of row
   * @param columnIndex The index of column in the row
   * @param columnSubRowIndex The index of sub row of column in the row
   */
  const getItems = (rowIndex: number, columnIndex: number, columnSubRowIndex: number) => {
    const item = dataList.data.slice(0 + 6 * rowIndex, 6 + 6 * rowIndex).slice(0 + 2 * columnIndex, 2 + 2 * columnIndex)[columnSubRowIndex];
    
    return item;
  };
  
  // get Color Class
  const getColorClass = () => {
    const index = Math.floor(Math.random() * 3);
    const classArray = ['light-green', 'black-bg', 'ligth-blue'];
    
    return classArray[index];
  };

  return (
    <div className="tab-contents tab-general">
      <div className="container">
        <div className="row hide">
          <div className="col col-md-6">
            <div className="general-content ">
              <h3>{maxNumberRow}
                Odyssey Bank implements 
                cloud-based nCino Bank 
                Operating System®, to provide 
                an omnichannel and agile 
                customer experience.
              </h3>
              <div className="greneral-content-action">
                <p className="left-txt">4 March 2021</p>
                <a href="#javascript" className="icons icon-circle-arrow-right-dark">&nbsp;</a>
              </div>
            </div>
          </div>
          <div className="col col-md-6">
            <div className="general-content img-style ">
              <div className="top-photo">
                <img src="/assets/gen-photo.jpg" alt="img" />
              </div>
              <div className="img-txt-area dark">
                <div className="txt white">
                  FCA performance scorecard - Personal Current Accounts.
                </div>
                <div className="greneral-content-action white">
                  <p className="left-txt">8 February 2021</p>
                  <a href="#javascript" className="icons icon-circle-arrow-right-white">&nbsp;</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {
          (new Array(Math.ceil(dataList.data.length / 6)).fill('')).map((rowItem, rowIndex) => (
            <div className="row" key={rowIndex}>
              <div className="col col-md-4 hide">
                <div className="general-content img-style ">
                  <div className="img-txt-area dark-blue">
                    <div className="txt">
                      KPMG & Savills Webinar.
                    </div>
                    <div className="greneral-content-action">
                      <p className="left-txt">8 February 2021</p>
                      <a href="#javascript" className="icons icon-circle-arrow-right-dark">&nbsp;</a>
                    </div>
                  </div>
                  <div className="bottom-photo">
                    <img src="/assets/pexels-thisiseng.jpg" alt="img" />
                  </div>
                </div>
              </div>
              {
                (new Array(Math.ceil(dataList.data.slice(0 + 6 * rowIndex, 6 + 6 * rowIndex).length / 2)).fill('')).map((columnItem, columnIndex) => (
                  <div className="col col-md-4 general-middle-content" key={columnIndex}>
                    {
                      (new Array(Math.ceil(dataList.data.slice(0 + 6 * rowIndex, 6 + 6 * rowIndex).slice(0 + 2 * columnIndex, 2 + 2 * columnIndex).length)).fill('')).map((columnSubRowItem, columnSubRowIndex) => (
                        <div className={`general-content ${getColorClass()}`} key={columnSubRowIndex}>
                          <h3>
                            {getItems(rowIndex, columnIndex, columnSubRowIndex)?.attributes.title}
                          </h3>
                          <div className="greneral-content-action">
                            <p className="left-txt">{moment(getItems(rowIndex, columnIndex, columnSubRowIndex)?.attributes.changed).format(DATE_FORMAT)}</p>
                            <NavLink to={`/about_us/article_detail/${getItems(rowIndex, columnIndex, columnSubRowIndex)?.id}`}
                              className="icons icon-circle-arrow-right">
                              &nbsp;
                            </NavLink>
                          </div>
                        </div>
                      ))
                    }
                  </div>
                ))
              }
            </div>
          ))
        }
      </div>
    </div>
  );
};

export default NewsArticlesList;
