import React from 'react';
import './styles.scss';

export interface IHighlightedSectionProps {
  info: any,
  cards: any,
}

export const HighlightedSection: React.FunctionComponent<IHighlightedSectionProps> = (props) => {

  return (
    <div className="highlighted-section flex">
      <div className="container">
        <div className='flex flex-md-row flex-column align-items-stretch'>
          <div className='left-section'>
            <div className="title">{props?.info?.data.attributes.field_title}</div>
            <div className="desc" dangerouslySetInnerHTML={{ __html: props?.info?.data.attributes.field_text.processed}}/>
          </div>
          <div className='right-section flex flex-row flex-wrap'>
            {props?.cards?.data.map((card: any, i: number) =>
              <div className="section-card" key={i}>
                <i className={`icons ${card.attributes.field_icon_class}`}/>
                <div className="txt" dangerouslySetInnerHTML={{ __html: card.attributes.field_text.processed}}/>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HighlightedSection;
