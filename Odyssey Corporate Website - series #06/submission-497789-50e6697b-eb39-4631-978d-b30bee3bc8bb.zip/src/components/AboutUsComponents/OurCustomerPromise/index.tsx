import React from 'react';
import './styles.scss';

interface IOurCustomerPromiseProps {
  dataList: any;
}

const OurCustomerPromise: React.FunctionComponent<IOurCustomerPromiseProps> = (
  props,
) => {
  const { dataList } = props;

  return (
    <div className="section-our-customer-promise">
      <div className="container">
        <h2>{dataList.attributes.field_title}</h2>
        <div
          className="txt"
          dangerouslySetInnerHTML={{
            __html: dataList.attributes.field_text.value,
          }}></div>
      </div>
    </div>
  );
};

export default OurCustomerPromise;
