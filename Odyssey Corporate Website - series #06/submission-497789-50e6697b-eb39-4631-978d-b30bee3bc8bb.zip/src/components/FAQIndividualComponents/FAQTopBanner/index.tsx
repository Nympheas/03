import React from 'react';
import './styles.scss';

export interface IFAQTopBannerProps {
}

export const FAQTopBanner: React.FunctionComponent<IFAQTopBannerProps> = (props) => {  
  
  return (
    <React.Fragment>
      <div className="section section-faq-individual-banner">
          <div className="hero-business-content">
            <div className="white-big-txt">
              Online Security
            </div>
          </div>
      </div>
    </React.Fragment>
  );
};

export default FAQTopBanner;
