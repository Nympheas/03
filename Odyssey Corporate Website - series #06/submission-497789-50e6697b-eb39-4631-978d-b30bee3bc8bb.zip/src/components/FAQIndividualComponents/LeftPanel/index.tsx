import React from 'react';
import './styles.scss';

export interface ILeftPanelProps {
  dataList?: any;
}

export const LeftPanel: React.FunctionComponent<ILeftPanelProps> = (props) => {
  const { dataList } = props;

  return (
    <React.Fragment>
      <div className="section section-faq-individual-left-panel">
        {
          dataList.data.map((item: any, index: number) => (
            <div className="panel" key={index}>
              <div className="title">{item.attributes.field_title}</div>
              <p className="txt-p"
                dangerouslySetInnerHTML={{ __html: item.attributes.field_text.processed }}>
              </p>
            </div>
          ))
        }
      </div>
    </React.Fragment>
  );
};

export default LeftPanel;
