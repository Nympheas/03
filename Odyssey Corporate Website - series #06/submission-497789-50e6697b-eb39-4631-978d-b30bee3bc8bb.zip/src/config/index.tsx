/*
 * Copyright (c) 2017 Topcoder, Inc. All rights reserved.
 */

/*
 * App configurations
 */
 
export const BASE_URL = 'http://localhost:3000';

export const BASE_IMAGE_URL = 'http://cms.dev.cynfusion.net';

export const DATE_FORMAT = 'DD MMMM YYYY';

export const LOADING_IMAGE_WAIT_TIME = 2000;

export const META = {
  PAGE_TITLE_SUFFIX: 'Odyssey Corporate Website',
  PAGE_DESCRIPTION: 'Odyssey Corporate Website',
  PAGE_KEYWORDS: 'Odyssey Corporate Website',
};

export const DataServiceId = {
  HomeId: 'a2d12474-f579-46aa-8b9d-3b2701ba3357',
  BridgingFinanceId: '764a6bb4-62a7-4d1b-8412-97c38a96fcbc',
  MeetTheTeamId: '1d1cf35d-4d4a-4f37-81c7-18e98cf18250',
  PersonalSavingsOnlineISAId: 'f7e04288-16c6-4334-86cf-102d319289dd',
  BusinessRelationshipManagerId: '53790fa2-1964-4eab-981a-7c2fa7c65ea9',
  FAQIndividualId: '63013474-6f9b-4b9f-873d-c7e27ff5e4b3',
  AboutUsId: '21c4d958-3883-4365-a102-1f1f8b95c50c',
  BusinessCurrentAccountId: '4ad01617-ac26-41b7-96a9-421c9f8bba8b',
  PersonalCurrentAccountId: '9dd0bd2c-df6c-43e2-a64d-be0c9d8792e4',
  BussinessCurrentAccountPremiumId: '256010fd-7bcb-4336-9622-9721064dce48',
  PersonalCurrentAccountPremiumId: '2274325f-0e1e-4f49-8bd4-51370cde58a8',
}