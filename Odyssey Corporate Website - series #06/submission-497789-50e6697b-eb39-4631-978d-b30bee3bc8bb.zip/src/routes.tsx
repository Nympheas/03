import {META} from './config';
import HomePage from './containers/HomePage';
import NewsArticlesPage from './containers/NewsArticlesPage';

import BridgingFinancePage from './containers/BridgingFinancePage';
import MeetTheTeamPage from './containers/MeetTheTeamPage';
import PersonalSavingsOnlineISAPage from './containers/PersonalSavingsOnlineISAPage';

import BusinessRelationshipManagerPage from './containers/BusinessRelationshipManagerPage';
import ArticleDetailPage from './containers/ArticleDetailPage';
import FAQIndividualPage from './containers/FAQIndividualPage';

import BusinessCurrentAccount from './containers/BusinessCurrentAccount';
import PersonalCurrentAccount from './containers/PersonalCurrentAccount';
import PersonalSavingAccount from './containers/PersonalSavingAccount';

import AboutUsPage from './containers/AboutUsPage';
import BussinessCurrentAccountPremium from './containers/BussinessCurrentAccountPremium';
import PersonalCurrentAccountPremium from './containers/PersonalCurrentAccountPremium';

/**
 * Generate an object with all necessary fields to render a page.
 * @param {string} path - The page path
 * @param {string} title - THe page title (for SEO)
 * @param {Function} component - The component to be rendered. Containers can also be used
 * @param {string} description - The page description (for SEO) [OPTIONAL]
 * @param {string} keywords - The comma separated page keywords (for SEO) [OPTIONAL]
 * @returns {object}
 */
export const createPage = (
  path: any,
  title: any,
  component: any,
  description?: any,
  keywords?: any,
) => ({
  path,
  title: `${title} | ${META.PAGE_TITLE_SUFFIX}`,
  component,
  description: description || META.PAGE_DESCRIPTION,
  keywords: keywords || META.PAGE_KEYWORDS,
});

const exportRoute = [
  createPage('/', 'HomePage', HomePage),
  createPage('/homePage', 'HomePage', HomePage),
  createPage('/about_us/news_and_articles', 'NewsArticlesPage', NewsArticlesPage),
  
  createPage('/business/business_finance', 'BridgingFinancePage', BridgingFinancePage),
  createPage('/private_banking/meet_the_team', 'MeetTheTeamPage', MeetTheTeamPage),
  createPage('/business/savings', 'PersonalSavingsOnlineISAPage', PersonalSavingsOnlineISAPage),
  
  createPage('/business/relationship_finance', 'BusinessRelationshipManagerPage', BusinessRelationshipManagerPage),
  createPage('/about_us/article_detail/:id', 'ArticleDetailPage', ArticleDetailPage),
  createPage('/customer_suppor/faqs', 'FAQIndividualPage', FAQIndividualPage),
  
  createPage('/business/current_accounts', 'BusinessCurrentAccount', BusinessCurrentAccount),
  createPage('/personal/savings', 'PersonalSavingsAccount', PersonalSavingAccount),
  createPage('/personal/current_account', 'PersonalCurrentAccount', PersonalCurrentAccount),
  
  createPage('/business/current_accounts_premium', 'BussinessCurrentAccountPremium', BussinessCurrentAccountPremium),
  createPage('/personal/current_account_premium', 'PersonalCurrentAccountPremium', PersonalCurrentAccountPremium),
  createPage('/about_us/cynergybank', 'AboutUsPage', AboutUsPage),
];

export default exportRoute;