import React, {useEffect, useState} from 'react';
import {bindActionCreators, Dispatch} from 'redux';
import {connect} from 'react-redux';
import nprogress from 'accessible-nprogress';
import dataAction from '../../actions/dataAction';
import dataSvc from '../../services/dataSvc';
import Header from '../../components/Header';
import RelatedProductsAndServices from '../../components/RelatedProductsAndServices';
import FAQTopBanner from '../../components/FAQIndividualComponents/FAQTopBanner';
import LeftPanel from '../../components/FAQIndividualComponents/LeftPanel';
import RelatedFAQ from '../../components/FAQIndividualComponents/RelatedFAQ';
import NotWhatYouAreLookingFor from '../../components/FAQIndividualComponents/NotWhatYouAreLookingFor';
import Breadcrumb from '../../components/Breadcrumb';
import Footer from '../../components/Footer';
import LowestFooter from '../../components/LowestFooter';
import { CommonDataModel } from '../../model/common-data.model';
import './styles.scss';

const parentField = "Customer Support";

interface IFAQIndividualPageProps {
  faqIndividualContent: any;
  faqList: CommonDataModel;
  relatedFAQs: CommonDataModel;
  relatedItems: CommonDataModel;
  headerMenu: CommonDataModel;
  footer: CommonDataModel;
  dataAction?: any;
}

const FAQIndividualPage: React.FunctionComponent<IFAQIndividualPageProps> = (props) => {  
  const [faqList, setFAQList] = useState<CommonDataModel>();
  const [relatedFAQs, setRelatedFAQs] = useState<CommonDataModel>();
  const [relatedItems, setRelatedItems] = useState<CommonDataModel>();
  const [headerMenu, setHeaderMenu] = useState<CommonDataModel>();
  const [footer, setFooter] = useState<CommonDataModel>();
  
  const breadcrumbArray = [
    {
      label: 'Home',
      url: '/'
    },
    {
      label: 'Customer Support',
      url: '#'
    },
    {
      label: 'Online Security',
      url: '#'
    }
  ];
  
  useEffect(() => {
    nprogress.configure({parent: 'main'});
    nprogress.start();
    props.dataAction.getFAQIndividualContentData();
    props.dataAction.getHeaderMenuData(parentField);
    props.dataAction.getFooterData();
  }, [props.dataAction]);
  
  useEffect(() => {
    if (props.faqIndividualContent) {      
      dataSvc.getFAQIndividualFAQListData(props.faqIndividualContent.data.id).then((data) => {
        setFAQList(data);
      })
      
      dataSvc.getFAQIndividualRelatedFAQsData(props.faqIndividualContent.data.id).then((data) => {
        setRelatedFAQs(data);
      })
      
      dataSvc.getFAQIndividualRelatedItemsData(props.faqIndividualContent.data.id).then((data) => {
        setRelatedItems(data);
      })
    }
    // eslint-disable-next-line
  }, [props.faqIndividualContent]);
  
  useEffect(() => {
    if (props.headerMenu) {
      setHeaderMenu(props.headerMenu);
    }
  }, [props.headerMenu]);
  
  useEffect(() => {
    if (props.footer) {
      setFooter(props.footer);
    }
  }, [props.footer]);

  nprogress.done();

  return (
    <React.Fragment>     
      {!!headerMenu && (
        <Header
          activeMenu={parentField}
          dataList={headerMenu} />
      )}
      
      <FAQTopBanner  />
          
      <Breadcrumb itemArray={breadcrumbArray}/>
      
      <div className="faq-individual-wrap">
      {faqList && (
        <LeftPanel
          dataList={faqList} />
      )}
      
      {relatedFAQs && (
        <RelatedFAQ
          dataList={relatedFAQs} />
      )}
      </div>
      
      {relatedItems && (
        <RelatedProductsAndServices
          dataList={relatedItems} />
      )}
      
      <NotWhatYouAreLookingFor />

      <div className="footer">
        {!!footer && (
          <Footer 
            dataList={footer} />
        )}
        
        <LowestFooter />
      </div>
    </React.Fragment>
  );
};

const mapStateToProps = (state: any) => ({...state.dataReducer});

const matchDispatchToProps = (dispatch: Dispatch) => ({
  actions: bindActionCreators({}, dispatch),
  dataAction: bindActionCreators({...dataAction}, dispatch),
});

export default connect(mapStateToProps, matchDispatchToProps)(FAQIndividualPage);
