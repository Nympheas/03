﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PMMC.Attributes;
using PMMC.Helpers;
using PMMC.Interfaces;
using PMMC.Models;
using System.Collections.Generic;

namespace PMMC.Controllers
{
    /// <summary>
    /// The worklist controller
    /// </summary>
    [Authorize]
    [ApiController]
    [DefaultRouting]
    public class WorklistController : BaseController
    {
        /// <summary>
        /// The logger used in controller
        /// </summary>
        private readonly ILogger<WorklistController> _logger;

        /// <summary>
        /// The worklist layout service used in controller
        /// </summary>
        private readonly IWorklistLayoutService _worklistLayoutService;

        /// <summary>
        /// The worklist account service used in controller
        /// </summary>
        private readonly IWorklistAccountService _worklistAccountService;

        /// <summary>
        /// Constructor with logger, worklist layout service, http context accessor
        /// </summary>
        /// <param name="logger">the logger </param>
        /// <param name="worklistLayoutService">the worklist layout service</param>
        /// <param name="httpContextAccessor">the http context accessor</param>
        public WorklistController(ILogger<WorklistController> logger, IWorklistLayoutService worklistLayoutService, IWorklistAccountService worklistAccountService,
            IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            _logger = logger;
            _worklistLayoutService = worklistLayoutService;
            _worklistAccountService = worklistAccountService;
        }

        /// <summary>
        /// Get all worklist layouts for current user
        /// </summary>
        /// <returns>all worklist layouts for current user</returns>
        [HttpGet]
        [Route("layouts")]
        public IEnumerable<WorklistLayout> GetAllWorklistLayouts()
        {
            return _logger.Process(() => _worklistLayoutService.GetAllWorklistLayouts(CurrentUser), "get all current user's worklist layouts");
        }

        /// <summary>
        /// Get worklist layout by id
        /// </summary>
        /// <param name="layoutId">the worklist layout id</param>
        /// <returns>match worklist layout by id</returns>
        [HttpGet]
        [Route("layouts/{layoutId}")]
        public WorklistLayout GetWorklistLayoutById([FromRoute] int layoutId)
        {
            return _logger.Process(() => _worklistLayoutService.GetWorklistLayoutById(layoutId, CurrentUser), "get worklist layout with the given Id",
                parameters: layoutId);
        }

        /// <summary>
        /// Create worklist layout
        /// </summary>
        /// <param name="worklistLayout">the worklist layout to create</param>
        /// <returns>the new created worklist layout with id</returns>
        [HttpPost]
        [Route("layouts")]
        public WorklistLayout CreateWorklistLayout([FromBody] WorklistLayout worklistLayout)
        {
            return _logger.Process(() => _worklistLayoutService.CreateWorklistLayout(worklistLayout, CurrentUser), "creates new worklist layout",
                parameters: worklistLayout);
        }

        /// <summary>
        /// Update worklist layout
        /// </summary>
        /// <param name="layoutId">the worklist layout id</param>
        /// <param name="worklistLayout">the worklist layout to update</param>
        [HttpPut]
        [Route("layouts/{layoutId}")]
        public void UpdateWorklistLayout([FromRoute] int layoutId, [FromBody] WorklistLayout worklistLayout)
        {
            _logger.Process(() => _worklistLayoutService.UpdateWorklistLayout(layoutId, worklistLayout, CurrentUser), "updates worklist layout with the given Id",
                parameters: new object[] { layoutId, worklistLayout });
        }

        /// <summary>
        /// Delete worklist layout by id
        /// </summary>
        /// <param name="layoutId">the worklist layout id</param>
        [HttpDelete]
        [Route("layouts/{layoutId}")]
        public void DeleteWorklistLayout([FromRoute] int layoutId)
        {
            _logger.Process(() => _worklistLayoutService.DeleteWorklistLayout(layoutId, CurrentUser), "deletes worklist layout with the given Id",
                parameters: layoutId);
        }

        /// <summary>
        /// Get all revcpt codes for the patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <returns>match revcpt codes for the patient id</returns>
        [HttpGet]
        [Route("accounts/{patientId}/revCpt")]
        public IEnumerable<RevCptCode> GetRevCptCodes([FromRoute] int patientId)
        {
            return _logger.Process(() => _worklistAccountService.GetRevCptCodes(patientId, CurrentUser), "get revcpt codes with the given patient id",
                parameters: patientId);
        }

        /// <summary>
        /// Get all charge codes for the patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <returns>match charge codes for the patient id</returns>
        [HttpGet]
        [Route("accounts/{patientId}/chargeCodes")]
        public IEnumerable<ChargeCodeDetail> GetChargeCodes([FromRoute] int patientId)
        {
            return _logger.Process(() => _worklistAccountService.GetChargeCodes(patientId, CurrentUser), "get worklist layout with the given Id",
                parameters: patientId);
        }

        /// <summary>
        /// Create charge code
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCode">the charge code to create</param>
        /// <returns>the new created charge code with id</returns>
        [HttpPost]
        [Route("accounts/{patientId}/chargeCodes")]
        public ChargeCodeDetail CreateChargeCode([FromRoute] int patientId, [FromBody] ChargeCodeDetail chargeCode)
        {
            return _logger.Process(() => _worklistAccountService.CreateChargeCode(patientId, chargeCode, CurrentUser), "creates new charge code",
                parameters: new object[] { patientId, chargeCode });
        }

        /// <summary>
        /// Update charge code
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCodeId">the charge code id to update</param>
        /// <param name="chargeCode">the charge code to update</param>
        [HttpPut]
        [Route("accounts/{patientId}/chargeCodes/{chargeCodeId}")]
        public void UpdateChargeCode([FromRoute] int patientId, [FromRoute] int chargeCodeId, [FromBody] ChargeCodeDetail chargeCode)
        {
            _logger.Process(() => _worklistAccountService.UpdateChargeCode(patientId, chargeCodeId, chargeCode, CurrentUser), "updates charge code",
                parameters: new object[] { patientId, chargeCodeId, chargeCode });
        }

        /// <summary>
        /// Delete charge code by id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCodeId">the charge code id</param>
        [HttpDelete]
        [Route("accounts/{patientId}/chargeCodes/{chargeCodeId}")]
        public void DeleteChargeCode([FromRoute] int patientId, [FromRoute] int chargeCodeId)
        {
            _logger.Process(() => _worklistAccountService.DeleteChargeCode(patientId, chargeCodeId, CurrentUser), "deletes charge code with the given Id",
                parameters: new object[] { patientId, chargeCodeId });
        }

        /// <summary>
        /// Get claim history by patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <returns>match claim history by patient id</returns>
        [HttpGet]
        [Route("accounts/{patientId}/claimsHistory")]
        public ClaimAndRemitHistory GetClaimsHistory([FromRoute] int patientId)
        {
            return _logger.Process(() => _worklistAccountService.GetClaimsHistory(patientId, CurrentUser), "get claim history",
                parameters: new object[] { patientId });
        }

        /// <summary>
        /// Get professional claims by patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <returns>match professional claim by patient id</returns>
        [HttpGet]
        [Route("accounts/{patientId}/professionalClaims")]
        public IEnumerable<ClaimHistoryItem> GetProfessionalClaims([FromRoute] int patientId)
        {
            return _logger.Process(() => _worklistAccountService.GetProfessionalClaims(patientId, CurrentUser), "get professional claims",
                parameters: new object[] { patientId });
        }

        /// <summary>
        /// Search worklist accounts
        /// </summary>
        /// <param name="query">the search query</param>
        /// <param name="user">the jwt user</param>
        /// <returns>match worklist accounts</returns>
        [HttpGet]
        [Route("accounts")]
        public WorklistAccount SearchWorklistAccounts([FromQuery] WorklistAccountSearchQuery query)
        {
            return _logger.Process(() => _worklistAccountService.SearchWorklistAccounts(query, CurrentUser), "get worklist accounts",
                parameters: new object[] { query });
        }
    }
}
