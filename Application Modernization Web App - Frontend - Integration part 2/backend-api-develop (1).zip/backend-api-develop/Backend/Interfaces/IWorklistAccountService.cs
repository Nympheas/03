﻿using PMMC.Entities;
using PMMC.Models;
using System.Collections.Generic;

namespace PMMC.Interfaces
{
    /// <summary>
    /// The worklist account service interface
    /// </summary>
    public interface IWorklistAccountService
    {
        /// <summary>
        /// Get all revcpt codes for the patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>all revcpt codes for the patient id</returns>
        IEnumerable<RevCptCode> GetRevCptCodes(int patientId, JwtUser user);

        /// <summary>
        /// Get all charge codes for the patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>all charge codes for the patient id</returns>
        IEnumerable<ChargeCodeDetail> GetChargeCodes(int patientId, JwtUser user);

        /// <summary>
        /// Create charge code for the patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCode">the charge code</param>
        /// <param name="user">the jwt user</param>
        /// <returns>the new created charge code with id</returns>
        ChargeCodeDetail CreateChargeCode(int patientId, ChargeCodeDetail chargeCode, JwtUser user);

        /// <summary>
        /// Update charge code
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCodeId">the charge code id to update</param>
        /// <param name="chargeCode">the charge code to update</param>
        /// <param name="user">the jwt user</param>
        void UpdateChargeCode(int patientId, int chargeCodeId, ChargeCodeDetail chargeCode, JwtUser user);

        /// <summary>
        /// Delete charge code by id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCodeId">the charge code id</param>
        /// <param name="user">the jwt user</param>
        void DeleteChargeCode(int patientId, int chargeCodeId, JwtUser user);

        /// <summary>
        /// Get claims history by patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>match claims history by patient id</returns>
        ClaimAndRemitHistory GetClaimsHistory(int patientId, JwtUser user);

        /// <summary>
        /// Get professional claims by patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>match professional claims by patient id</returns>
        IEnumerable<ClaimHistoryItem> GetProfessionalClaims(int patientId, JwtUser user);

        /// <summary>
        /// Search worklist accounts
        /// </summary>
        /// <param name="query">the search query</param>
        /// <param name="user">the jwt user</param>
        /// <returns>match worklist accounts</returns>
        WorklistAccount SearchWorklistAccounts(WorklistAccountSearchQuery query, JwtUser user);
    }
}
