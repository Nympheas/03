﻿using Dapper;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PMMC.Configs;
using PMMC.Entities;
using PMMC.Exceptions;
using PMMC.Helpers;
using PMMC.Interfaces;
using PMMC.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace PMMC.Services
{
    /// <summary>
    /// The worklist account service
    /// </summary>
    public class WorklistAccountService : BaseService, IWorklistAccountService
    {
        /// <summary>
        /// The get all revcpt codes for the patient id sql
        /// </summary>
        internal const string GetRevCptCodesSql =
            "SELECT [RevCodeId] AS Id,[RevenueCode] AS RevenueCode,[RevCodeDescription] AS RevenueCodeDescription,[CPTTransId] AS TransactionId,[CPTCode] AS CptCode,[CPTDescr] AS CptCodeDescription,[ServiceDate] AS ServiceDate,[Mod1] AS Modifier1,[Mod2] AS Modifier2,[ServiceType] AS ServiceType,[PhysicianID] AS PhysicianId,[ServiceLocation] AS PointOfService,[Units] AS Units,[Charges] AS Charges,[DeniedCharges] AS DeniedCharges,[ExcludedCharges] AS NonCoveredCharges,[NonBilledCharges] AS NonBilledCharges,[Cost] AS Cost FROM [dbo].[RevCPTDetail] WHERE [patientid] = @patientId";

        /// <summary>
        /// The get all charge codes for the patient id sql
        /// </summary>
        internal const string GetChargeCodesSql =
            "SELECT [Id] AS Id,[Code] AS ChargeCode,[RevenueCode] AS RevenueCode,[DeniedCharges] AS DeniedCharges,[Description] AS Description,[CPT] AS CptCode,[ExcludedCharges] AS NonCoveredCharges,[TransactionID] AS TransactionId,[Units] AS Units,[NonBillCharges] AS NonBilledCharges,[ServiceDate] AS ServiceDate,[charges] AS Charges,[Cost] AS Cost FROM [dbo].[ChargeCodeDetails] WHERE [ActualPatientID]=@patientId";

        /// <summary>
        /// The get charge code by id sql
        /// </summary>
        internal const string GetChargeCodeByIdSql =
            "SELECT [Id] AS Id,[Code] AS ChargeCode,[RevenueCode] AS RevenueCode,[DeniedCharges] AS DeniedCharges,[Description] AS Description,[CPT] AS CptCode,[ExcludedCharges] AS NonCoveredCharges,[TransactionID] AS TransactionId,[Units] AS Units,[NonBillCharges] AS NonBilledCharges,[ServiceDate] AS ServiceDate,[charges] AS Charges,[Cost] AS Cost FROM [dbo].[ChargeCodeDetails] WHERE [ActualPatientID]=@patientId AND [Id]=@chargeCodeId";

        /// <summary>
        /// The create charge code sql
        /// </summary>
        internal const string CreateChargeCodeSql =
            "INSERT INTO [dbo].[ChargeCodeDetails]([Code],[RevenueCode],[DeniedCharges],[Description],[CPT],[ExcludedCharges],[TransactionID],[Units],[NonBillCharges],[ServiceDate],[charges],[Cost],[ActualPatientID]) OUTPUT INSERTED.[Id] VALUES(@ChargeCode,@RevenueCode,@DeniedCharges,@Description,@CptCode,@NonCoveredCharges,@TransactionId,@Units,@NonBilledCharges,@ServiceDate,@Charges,@Cost,@patientId)";

        /// <summary>
        /// The update charge code sql
        /// </summary>
        internal const string UpdateChargeCodeSql =
            "UPDATE [dbo].[ChargeCodeDetails] SET [Code]=@ChargeCode,[RevenueCode]=@RevenueCode,[DeniedCharges]=@DeniedCharges,[Description]=@Description,[CPT]=@CptCode,[ExcludedCharges]=@NonCoveredCharges,[TransactionID]=@TransactionId,[Units]=@Units,[NonBillCharges]=@NonBilledCharges,[ServiceDate]=@ServiceDate,[charges]=@Charges,[Cost]=@Cost WHERE [ActualPatientID]=@patientId AND Id=@chargeCodeId";

        /// <summary>
        /// The delete charge code sql
        /// </summary>
        internal const string DeleteChargeCodeSql =
            "DELETE [dbo].[ChargeCodeDetails] WHERE [ActualPatientID]=@patientId AND Id=@chargeCodeId";

        /// <summary>
        /// The get claims history sql
        /// </summary>
        internal const string GetClaimsHistorySql =
            "SELECT [ch].ID AS Id,[ch].[ClaimNumber] AS PatientControlNumber,[ch].[PrimaryPayer] AS PrimaryPayer,[ch].[BillType] AS BillType,[ch].[ClaimFreqType] AS ClaimFrequencyType,[ch].[BillingDate] AS BillingDate,[ch].[ClaimNumber] AS ClaimNumber,[ch].[StatementFromDate] AS StatementFromDate,[ch].[StatementToDate] AS StatementToDate,[ch].[TotalCharges] AS TotalCharges,[ch].[TotalNonCoveredCharges] AS TotalNonCoveredCharges,[ch].[PatientEstAmtDue] AS PatientEstAmtDue,LineCount=0,[ch].[DestinationPayer] AS DestinationPayer,[ch].[DestinationPayerResp] AS DestinationPayerResponsibility,[cd].[ID] AS Id,[cd].[LineNumber] AS LineNumber,[cd].[ServiceDate] AS [Date],[cd].[RevenueCode] AS RevenueCode,[cd].[CPTCode] AS HcpcsCptCode,[cd].[Modifier] AS Modifier,[cd].[Quantity] AS Quantity,[cd].[TotalCharges] AS Charges,[cd].[NonCoveredCharges] AS NonCoveredCharges FROM [dbo].[ClaimHistory] [ch] LEFT JOIN [dbo].[ClaimDetail] [cd] ON [cd].[iClaimId]=[ch].[ID] WHERE [ActualPatientID]=@patientId";

        /// <summary>
        /// The get claims history sql
        /// </summary>
        internal const string GetRemitsHistorySql =
            "SELECT [rh].[ID] AS Id,[rh].[Name] AS [Provider],[rh].[PayeeID] AS Payer,[rh].[BillType] AS BillType,[rh].[ClaimFrequencyType] AS ClaimFrequencyType,[rh].[EffectiveDate] AS [EffectiveDate],[rh].[CheckNumber] AS CheckNumber,[rh].[StatementFromDate] AS StatementFromDate,[rh].[StatementToDate] AS StatementToDate,[rh].[ClaimStatusCode] AS ClaimStatus,(SELECT SUM([rds].[Charges]) FROM [dbo].[RemitDetail] rds WHERE [rds].[RemitID]=[rh].[ID]) AS ClaimBilledAmount,[rh].[CoverageAmt] AS ClaimPaidAmount,[rh].[AdjAmt] AS ClaimLevelAdjustAmount,[rh].[DenialAmt] AS ClaimLevelDenialAmount,(SELECT SUM([rds].[Charges])-SUM([rds].[ActualAllowedAmt]) FROM [dbo].[RemitDetail] rds WHERE [rds].[RemitID]=[rh].[ID]) AS LineLevelAdjustAmount,(SELECT SUM([rds].[DenialAmt]) FROM [dbo].[RemitDetail] rds WHERE [rds].[RemitID]=[rh].[ID]) AS LineLevelDenialAmount,(SELECT COUNT([rds].[ID]) FROM [dbo].[RemitDetail] rds WHERE [rds].[RemitID]=[rh].[ID]) AS LineCount,[rh].[AdjRsnCodes] AS ClaimLevelAdjustReasonCodes,[rh].[RemarkCodes] AS ClaimLevelRemarkCodes,[rh].[ClaimNumber] AS ClaimNumber,[rd].[ID] AS Id,[rd].[AdjRsnCode] AS AdjustmentReasonCodes,[rd].[RemarkCode] AS RemarkCodes FROM [dbo].[RemitHistory] [rh] LEFT JOIN [dbo].[RemitDetail] [rd] ON [rd].[RemitID]=[rh].[ID] WHERE [rh].[ActualPatientID]=@patientId";

        /// <summary>
        /// The validate patient id sql
        /// </summary>
        internal const string ValidatePatientIdSql =
            "SELECT CASE WHEN EXISTS (SELECT 1 FROM [dbo].[tblWorklistData] WHERE [ActualPatientID]=@patientId) THEN 1 ELSE 0 END";

        /// <summary>
        /// The filter logic
        /// </summary>
        internal const string GetFilterLogic =
            "SELECT [Description] FROM [dbo].[tblComboBoxesSystemValues] WHERE [CodeType]='{0}' AND [Code]={1}";

        /// <summary>
        /// The validate sort by sql
        /// </summary>
        internal const string ValidateSortBy =
            "SELECT CASE WHEN EXISTS(SELECT 1 FROM [dbo].[tblColumns] WHERE [DataField]=@SortBy) THEN 1 ELSE 0 END";

        /// <summary>
        /// The get worklist layout by name sql
        /// </summary>
        internal const string GetDefaultWorklistLayoutColumnsSql =
            "SELECT [cd].[CustomDetailID] AS Id,[cd].[FieldName] AS FieldName,[cd].[FieldLocation] AS Location,[cd].[FieldWidth] AS Width, [cd].[FieldVisible] AS IsVisible  FROM [dbo].[tblColumnsCustom] [c] LEFT JOIN [dbo].[tblColumnsCustomDetail] [cd] ON [cd].[CustomID] = [c].[CustomID]  WHERE [c].[UserID]=@UserId AND [c].[DefaultView]=1";

        /// <summary>
        /// The get worklist layout by name sql
        /// </summary>
        internal const string GetDefaultColumnsSql =
            "SELECT [cd].[CustomDetailID] AS Id,[cd].[FieldName] AS FieldName,[cd].[FieldLocation] AS Location,[cd].[FieldWidth] AS Width, [cd].[FieldVisible] AS IsVisible  FROM [dbo].[tblColumnsCustomDetail] [cd] WHERE [cd].[CustomID]=1";

        private readonly IViewService _viewService;
        private readonly IWorklistLayoutService _worklistLayoutService;

        /// <summary>
        /// Constructor with logger and app settings
        /// </summary>
        /// <param name="logger">the logger</param>
        /// <param name="appSettings">the app settings</param>
        public WorklistAccountService(ILogger<WorklistAccountService> logger, IOptions<AppSettings> appSettings, IViewService viewService, IWorklistLayoutService worklistLayoutService) : base(logger, appSettings)
        {
            _viewService = viewService;
            _worklistLayoutService = worklistLayoutService;
        }

        /// <summary>
        /// Get all revcpt codes for the patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>all revcpt codes for the patient id</returns>
        public IEnumerable<RevCptCode> GetRevCptCodes(int patientId, JwtUser user)
        {
            return _logger.Process(() =>
            {
                Helper.ValidateArgumentNotNull(user, nameof(user));
                ValidatePatientId(patientId, user);
                return ProcessWithDb((conn) =>
                {
                    return conn.Query<RevCptCode>(GetRevCptCodesSql, new { patientId });
                }, user);
            }, "get all revcpt codes for the patient id",
                parameters: new object[] { patientId, user });
        }

        /// <summary>
        /// Get all charge codes for the patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>all charge codes for the patient id</returns>
        public IEnumerable<ChargeCodeDetail> GetChargeCodes(int patientId, JwtUser user)
        {
            return _logger.Process(() =>
            {
                Helper.ValidateArgumentNotNull(user, nameof(user));
                ValidatePatientId(patientId, user);
                return ProcessWithDb((conn) =>
                {
                    return conn.Query<ChargeCodeDetail>(GetChargeCodesSql, new { patientId });
                }, user);
            }, "get all charge codes for the patient id",
                parameters: new object[] { patientId, user });
        }

        /// <summary>
        /// Create charge code for the patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCode">the charge code</param>
        /// <param name="user">the jwt user</param>
        /// <returns>the new created charge code with id</returns>
        public ChargeCodeDetail CreateChargeCode(int patientId, ChargeCodeDetail chargeCode, JwtUser user)
        {
            return _logger.Process(() =>
            {
                ValidateChargeCode(chargeCode, user, patientId);
                return ProcessWithDbTransaction((conn) =>
                {
                    var newId = conn.QuerySingle<int>(CreateChargeCodeSql,
                        new
                        {
                            chargeCode.ChargeCode,
                            chargeCode.RevenueCode,
                            chargeCode.DeniedCharges,
                            chargeCode.Description,
                            chargeCode.CptCode,
                            chargeCode.NonCoveredCharges,
                            chargeCode.TransactionId,
                            chargeCode.Units,
                            chargeCode.NonBilledCharges,
                            chargeCode.ServiceDate,
                            chargeCode.Charges,
                            chargeCode.Cost,
                            patientId
                        });
                    chargeCode.Id = newId;
                    Audit(conn, new Audit
                    {
                        UserId = user.UserId,
                        OldValue = null,
                        NewValue = LoggerHelper.GetObjectDescription(chargeCode),
                        OperationType = OperationType.Create,
                        ObjectType = nameof(ChargeCodeDetail),
                        Timestamp = DateTime.Now
                    });
                    return chargeCode;
                }, user);
            }, "creates new charge code",
                parameters: new object[] { patientId, chargeCode, user });
        }

        /// <summary>
        /// Update charge code
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCodeId">the charge code id to update</param>
        /// <param name="chargeCode">the charge code to update</param>
        /// <param name="user">the jwt user</param>
        public void UpdateChargeCode(int patientId, int chargeCodeId, ChargeCodeDetail chargeCode, JwtUser user)
        {
            _logger.Process(() =>
            {
                ValidateChargeCode(chargeCode, user, patientId, chargeCodeId);
                var oldChargeCode = FindValidChargeCode(patientId, chargeCodeId, user);
                ProcessWithDbTransaction((conn) =>
                {
                    conn.Execute(UpdateChargeCodeSql,
                        new
                        {
                            chargeCode.ChargeCode,
                            chargeCode.RevenueCode,
                            chargeCode.DeniedCharges,
                            chargeCode.Description,
                            chargeCode.CptCode,
                            chargeCode.NonCoveredCharges,
                            chargeCode.TransactionId,
                            chargeCode.Units,
                            chargeCode.NonBilledCharges,
                            chargeCode.ServiceDate,
                            chargeCode.Charges,
                            chargeCode.Cost,
                            patientId,
                            chargeCodeId
                        });
                    chargeCode.Id = chargeCodeId;
                    Audit(conn, new Audit
                    {
                        UserId = user.UserId,
                        OldValue = LoggerHelper.GetObjectDescription(oldChargeCode),
                        NewValue = LoggerHelper.GetObjectDescription(chargeCode),
                        OperationType = OperationType.Update,
                        ObjectType = nameof(ChargeCodeDetail),
                        Timestamp = DateTime.Now
                    });
                }, user);
            }, "updates charge code with the given patient id and charge code id",
                parameters: new object[] { patientId, chargeCodeId, chargeCode, user });
        }

        /// <summary>
        /// Delete charge code by id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCodeId">the charge code id</param>
        /// <param name="user">the jwt user</param>
        public void DeleteChargeCode(int patientId, int chargeCodeId, JwtUser user)
        {
            _logger.Process(() =>
            {
                ValidatePatientId(patientId, user);
                var oldChargeCode = FindValidChargeCode(patientId, chargeCodeId, user);
                ProcessWithDbTransaction((conn) =>
                {
                    conn.Execute(DeleteChargeCodeSql, new { patientId, chargeCodeId });
                    Audit(conn, new Audit
                    {
                        UserId = user.UserId,
                        OldValue = LoggerHelper.GetObjectDescription(oldChargeCode),
                        NewValue = null,
                        OperationType = OperationType.Delete,
                        ObjectType = nameof(ChargeCodeDetail),
                        Timestamp = DateTime.Now
                    });
                }, user);
            }, "deletes charge code with the given Id",
                parameters: new object[] { patientId, chargeCodeId, user });
        }

        /// <summary>
        /// Get claims history by patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>match claims history by patient id</returns>
        public ClaimAndRemitHistory GetClaimsHistory(int patientId, JwtUser user)
        {
            return _logger.Process(() =>
            {
                Helper.ValidateArgumentNotNull(user, nameof(user));
                ValidatePatientId(patientId, user);
                return ProcessWithDb((conn) =>
                {
                    var Claims = GetClaims(patientId, conn);
                    var Remits = GetRemits(patientId, conn);
                    return new ClaimAndRemitHistory() { Claims = Claims, Remits = Remits };
                }, user);
            }, "get claims history by patient id",
                parameters: new object[] { patientId, user });
        }

        /// <summary>
        /// Get professional claims by patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>match professional claims by patient id</returns>
        public IEnumerable<ClaimHistoryItem> GetProfessionalClaims(int patientId, JwtUser user)
        {
            return _logger.Process(() =>
            {
                Helper.ValidateArgumentNotNull(user, nameof(user));
                ValidatePatientId(patientId, user);
                return ProcessWithDb((conn) =>
                {
                    return GetClaims(patientId, conn);
                }, user);
            }, "get professional claims by patient id",
                parameters: new object[] { patientId, user });
        }

        /// <summary>
        /// Search worklist accounts
        /// </summary>
        /// <param name="query">the search query</param>
        /// <param name="user">the jwt user</param>
        /// <returns>match worklist accounts</returns>
        public WorklistAccount SearchWorklistAccounts(WorklistAccountSearchQuery query, JwtUser user)
        {
            return _logger.Process(() =>
            {
                return ProcessWithDb((conn) =>
                {
                    query.SortBy = ValidateSearchAccountsSortBy(query.SortBy, conn);
                    query.SortOrder = ValidateSearchAccountsSortOrder(query.SortOrder);
                    // get the columns to use in SELECT statement.
                    IList<WorklistColumnLayout> selectedLayoutColumns = GetSelectedLayoutColumns(query.LayoutId, conn, user);
                    if (!query.Offset.HasValue) query.Offset = 0;
                    if (!query.Limit.HasValue) query.Limit = 20;
                    // get view rule by view id
                    var rules = _viewService.GetAllViewRules(query.ViewId.Value, user);
                    StringBuilder viewFilter = new StringBuilder();
                    Dictionary<int, string> valueTypes = new Dictionary<int, string>();
                    foreach (ViewRule rule in rules)
                    {
                        // create filters according to field selection type.
                        var field = rule.viewField;
                        if (IsSelectionType(_appSettings.DateRangeSelectionType, field.SelectionType))
                        {
                            viewFilter.Append($" AND [{field.Name}] BETWEEN '{rule.BeginRange}' AND '{rule.EndRange}'");
                        }
                        else if (IsSelectionType(_appSettings.DateTimeRangeSelectionType, field.SelectionType))
                        {
                            viewFilter.Append($" AND [{field.Name}] BETWEEN '{rule.BeginRange}' AND '{rule.EndRange}'");
                        }
                        else if (IsSelectionType(_appSettings.NumberSelectionType, field.SelectionType) || IsSelectionType(_appSettings.PercentSelectionType, field.SelectionType))
                        {
                            if (rule.Operand == _appSettings.RuleOperands.EqualTo)
                                viewFilter.Append($" AND [{field.Name}] = {rule.Value}");
                            else if (rule.Operand == _appSettings.RuleOperands.GreaterThan)
                                viewFilter.Append($" AND [{field.Name}] > {rule.Value}");
                            else if (rule.Operand == _appSettings.RuleOperands.LessThan)
                                viewFilter.Append($" AND [{field.Name}] < {rule.Value}");
                            else if (rule.Operand == _appSettings.RuleOperands.Between)
                                viewFilter.Append($" AND [{field.Name}] BETWEEN {rule.BeginRange} AND {rule.EndRange}");
                            else
                                throw new InternalServerErrorException($"Rule Operand: {rule.Operand} is not defined.");
                        }
                        else if (IsSelectionType(_appSettings.TextSelectionType, field.SelectionType))
                        {
                            if (rule.Operand == _appSettings.RuleOperands.StartsWith)
                                viewFilter.Append($" AND [{field.Name}] LIKE '{rule.Value}%'");
                            else if (rule.Operand == _appSettings.RuleOperands.EndsWith)
                                viewFilter.Append($" AND [{field.Name}] LIKE '%{rule.Value}'");
                            else if (rule.Operand == _appSettings.RuleOperands.Contains)
                                viewFilter.Append($" AND [{field.Name}] LIKE '%{rule.Value}%'");
                            else
                                throw new InternalServerErrorException($"Rule Operand: {rule.Operand} is not defined.");
                        }
                        else if (IsSelectionType(_appSettings.ValuesSelectionType, field.SelectionType))
                        {
                            var correctValue = field.IntegerFieldLink ? rule.ValueId : rule.Value;
                            if (valueTypes.ContainsKey(rule.FieldId))
                            {
                                valueTypes[rule.FieldId] = $"{valueTypes[rule.FieldId]},'{correctValue}'";
                            }
                            else
                            {
                                if (rule.Operand == _appSettings.RuleOperands.In)
                                    valueTypes[rule.FieldId] = $"[{field.Name}] IN ('{correctValue}'";
                                else if (rule.Operand == _appSettings.RuleOperands.NotIn)
                                    valueTypes[rule.FieldId] = $"[{field.Name}] NOT IN ('{correctValue}'";
                                else
                                    throw new InternalServerErrorException($"Rule Operand: {rule.Operand} is not defined.");
                            }
                        }
                    }
                    foreach (var statement in valueTypes.Values)
                    {
                        viewFilter.Append($" AND {statement})");
                    }

                    var queryAuditor = string.Format(GetFilterLogic, _appSettings.CodeTypes.Auditor, query.Auditor.Value);
                    var queryFollowUp = string.Format(GetFilterLogic, _appSettings.CodeTypes.FollowUp, query.FollowUp.Value);
                    var queryStatus = string.Format(GetFilterLogic, _appSettings.CodeTypes.Status, query.Status.Value);
                    var queryAccountAge = string.Format(GetFilterLogic, _appSettings.CodeTypes.AccountAge, query.AccountAge.Value);
                    var queryHiddenRecords = string.Format(GetFilterLogic, _appSettings.CodeTypes.HiddenRecords, query.HiddenRecords.Value);
                    var multiSQL = $"{queryAuditor};{queryFollowUp};{queryStatus};{queryAccountAge};{queryHiddenRecords}";
                    using (var multi = conn.QueryMultiple(multiSQL))
                    {
                        var auditor = multi.ReadSingleOrDefault<string>();
                        var followUp = multi.ReadSingleOrDefault<string>();
                        var status = multi.ReadSingleOrDefault<string>();
                        var accountAge = multi.ReadSingleOrDefault<string>();
                        var hiddenRecord = multi.ReadSingleOrDefault<string>();

                        switch (auditor)
                        {
                            case "All Records": break;
                            case "Assigned To Me": viewFilter.Append($" AND [AuditorId]={user.UserId}"); break;
                            case "Unassigned": viewFilter.Append($" AND ([AuditorId] IS NULL OR [AuditorId]=0)"); break;
                            default: throw new BadRequestException($"Auditor='{query.Auditor.Value}' is not valid");
                        }
                        switch (followUp)
                        {
                            case "All Records": break;
                            case "Past Due": viewFilter.Append($" AND [ActivityDate] < CONVERT(DATE, GETDATE())"); break;
                            case "Due Today or Past Due": viewFilter.Append($" AND [ActivityDate] <= CONVERT(DATE, GETDATE())"); break;
                            case "Due Within 1 Week": viewFilter.Append($" AND [ActivityDate] <= CONVERT(DATE,DATEADD(DAY,7,GETDATE()))"); break;
                            case "Due Within 1 Month": viewFilter.Append($" AND [ActivityDate] <= CONVERT(DATE,DATEADD(MONTH,1,GETDATE()))"); break;
                            default: throw new BadRequestException($"FollowUp='{query.FollowUp.Value}' is not valid");
                        }
                        switch (status)
                        {
                            case "Include All": break;
                            case "Exclude Closed": viewFilter.Append($" AND ([Status] != {_appSettings.ClosedStatusValue} OR [Status] IS NULL)"); break;
                            default: throw new BadRequestException($"Status='{query.Status.Value}' is not valid");
                        }
                        switch (accountAge)
                        {
                            case "All Records": break;
                            case "Within 1 Year": viewFilter.Append($" AND [Age] - [AgeOfClaim] <= 1"); break;
                            case "Within 2 Years": viewFilter.Append($" AND [Age] - [AgeOfClaim] <= 2"); break;
                            case "Within 3 Years": viewFilter.Append($" AND [Age] - [AgeOfClaim] <= 3"); break;
                            case "Within 4 Years": viewFilter.Append($" AND [Age] - [AgeOfClaim] <= 4"); break;
                            case "Within 5 Years": viewFilter.Append($" AND [Age] - [AgeOfClaim] <= 5"); break;
                            default: throw new BadRequestException($"AccountAge='{query.AccountAge.Value}' is not valid");
                        }
                        switch (hiddenRecord)
                        {
                            case "Include": break;
                            case "Exclude": viewFilter.Append($" AND [HiddenByUser] IS NOT NULL"); break;
                            default: throw new BadRequestException($"HiddenRecords='{query.HiddenRecords.Value}' is not valid");
                        }
                    }
                    if (viewFilter.ToString().StartsWith(" AND "))
                    {
                        viewFilter.Remove(0, 5);
                        viewFilter.Insert(0, "WHERE ");
                    }
                    var columns = selectedLayoutColumns.Where(x => x.IsVisible == true && x.FieldName != "PatientID" && x.FieldName != "ActualPatientID").OrderBy(o => o.Location).Select(x => x.FieldName).ToArray();
                    string finalQuery = $"SELECT [PatientId],[ActualPatientId]{(columns.Any() ? ",[" + string.Join("],[", columns) + "]" : "")} FROM [dbo].[tblWorklistData] {viewFilter} ORDER BY {query.SortBy} {query.SortOrder} OFFSET {query.Offset} ROWS FETCH NEXT {query.Limit} ROWS ONLY";
                    string countQuery = $"SELECT [Count]=COUNT(1) FROM [dbo].[tblWorklistData] {viewFilter}";
                    var result = conn.Query(finalQuery);
                    var totalCount = conn.QuerySingle<int>(countQuery);
                    var items = new List<WorklistAccountItem>();
                    foreach (IDictionary<string, object> row in result)
                    {
                        var values = new List<string>();
                        foreach (var col in columns)
                        {
                            values.Add(row[col].ToString());
                        }
                        items.Add(new WorklistAccountItem
                        {
                            PatientId = int.Parse(row["PatientId"].ToString()),
                            ActualPatientId = row["ActualPatientId"].ToString(),
                            Values = values.ToArray()
                        });
                    }
                    return new WorklistAccount
                    {
                        TotalCount = totalCount,
                        Items = items
                    };
                }, user);
            }, "search worklist accounts",
                parameters: new object[] { query, user });
        }

        /// <summary>
        /// Validates patient id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="user">the jwt user</param>
        /// <exception cref="NotFoundException">throws if patient is not found</exception>
        private void ValidatePatientId(int patientId, JwtUser user)
        {
            Helper.ValidateArgumentPositive(patientId, nameof(patientId));
            ProcessWithDb((conn) =>
            {
                var record = conn.QuerySingle<int>(ValidatePatientIdSql, new { patientId });
                if (record == 0)
                {
                    throw new NotFoundException($"Patient with patientId='{patientId}' not found");
                }
            }, user);
        }

        /// <summary>
        /// Get worklist layout by id
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCodeId">the charge code id</param>
        /// <param name="user">the jwt user</param>
        /// <returns>match worklist layout by id</returns>
        /// <exception cref="NotFoundException">throws if charge code is not found</exception>
        private ChargeCodeDetail FindValidChargeCode(int patientId, int chargeCodeId, JwtUser user)
        {
            Helper.ValidateArgumentPositive(patientId, nameof(patientId));
            Helper.ValidateArgumentPositive(chargeCodeId, nameof(chargeCodeId));
            Helper.ValidateArgumentNotNull(user, nameof(user));
            return ProcessWithDb((conn) =>
            {
                var record = conn.Query<ChargeCodeDetail>(GetChargeCodeByIdSql, new { patientId, chargeCodeId });
                if (!record.Any())
                {
                    throw new NotFoundException($"Charge code by patientId='{patientId}' and id='{chargeCodeId}' not found");
                }
                return record.First();
            }, user);
        }

        /// <summary>
        /// Validate charge code to ensure valid inputs
        /// </summary>
        /// <param name="chargeCode">the charge code to validate</param>
        /// <param name="user">the jwt user</param>
        /// <param name="patientId">the patient id</param>
        /// <param name="chargeCodeId">the updated charge code id</param>
        /// <exception cref="BadRequestException">throws if worklist layout is invalid</exception>
        private void ValidateChargeCode(ChargeCodeDetail chargeCode, JwtUser user, int patientId, int? chargeCodeId = null)
        {
            Helper.ValidateArgumentNotNull(chargeCode, nameof(chargeCode));
            Helper.ValidateArgumentNotNull(user, nameof(user));
            ValidatePatientId(patientId, user);
            if (chargeCodeId.HasValue)
            {
                Helper.ValidateArgumentPositive(chargeCodeId.Value, nameof(chargeCodeId));
            }
        }

        /// <summary>
        /// Check whether selection type is valid
        /// </summary>
        /// <param name="expectedSelectionType">the expected selection type</param>
        /// <param name="selectionType">the selection type to check</param>
        /// <returns>true if selection type match otherwise false</returns>
        private bool IsSelectionType(string expectedSelectionType, string selectionType)
        {
            return string.Equals(expectedSelectionType, selectionType, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Validates the sortBy parameter
        /// </summary>
        /// <param name="sortBy">the sortBy value</param>
        /// <param name="conn">the connection to be used for query</param>
        /// <returns>the sortBy value if it's valid or default value if it's empty</returns>
        /// <exception cref="BadRequestException">throws if sortBy parameter is invalid</exception>
        private string ValidateSearchAccountsSortBy(string sortBy, IDbConnection conn)
        {
            if (!string.IsNullOrEmpty(sortBy))
            {
                var sortByRecord = conn.QuerySingle<int>(ValidateSortBy, new { sortBy });
                if (sortByRecord == 0)
                {
                    throw new BadRequestException($"Sort By='{sortBy}' is not valid");
                }
                return sortBy;
            }
            else
            {
                return _appSettings.WorklistAccountsDefaultSortBy;
            }
        }

        /// <summary>
        /// Validates the sort order parameter
        /// </summary>
        /// <param name="sortOrder">the sortOrder value</param>
        /// <returns>the sortOrder value if it's valid or default value if it's empty</returns>
        /// <exception cref="BadRequestException">throws if sortOrder parameter is invalid</exception>
        private string ValidateSearchAccountsSortOrder(string sortOrder)
        {
            if (!string.IsNullOrEmpty(sortOrder))
            {
                if (sortOrder.ToLower() != "asc" && sortOrder.ToLower() != "desc")
                {
                    throw new BadRequestException($"Sort Order='{sortOrder}' is not valid");
                }
                return sortOrder;
            }
            else
            {
                return _appSettings.WorklistAccountsDefaultSortOrder;
            }
        }

        /// <summary>
        /// Gets the worklist column layouts of the given layout id
        /// </summary>
        /// <param name="layoutId">the sortOrder value</param>
        /// <param name="conn">the connection to be used for query</param>
        /// <param name="user">the current user</param>
        /// <returns>the list of worklist column layouts</returns>
        private IList<WorklistColumnLayout> GetSelectedLayoutColumns(int? layoutId, IDbConnection conn, JwtUser user)
        {
            if (layoutId.HasValue)
            {
                return _worklistLayoutService.GetWorklistLayoutById(layoutId.Value, user).Columns;
            }
            else
            {
                var layoutColumns = conn.Query<WorklistColumnLayout>(GetDefaultWorklistLayoutColumnsSql, new { user.UserId });
                if (layoutColumns.Any())
                {
                    return layoutColumns.ToList();
                }
                else
                {
                    return conn.Query<WorklistColumnLayout>(GetDefaultColumnsSql).ToList();
                }
            }
        }

        /// <summary>
        /// Gets the claim history items with details
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="conn">the connection to be used for query</param>
        /// <returns>the list of claim history items</returns>
        private List<ClaimHistoryItem> GetClaims(int patientId, IDbConnection conn)
        {
            var claims = new Dictionary<int, ClaimHistoryItem>();
            conn.Query<ClaimHistoryItem, ClaimDetailItem, ClaimHistoryItem>(GetClaimsHistorySql, (claimItems, claimDetailItems) =>
            {
                if (!claims.TryGetValue(claimItems.Id, out ClaimHistoryItem claimHistoryItem))
                    claims.Add(claimItems.Id, claimHistoryItem = claimItems);
                if (claimHistoryItem.ClaimDetails == null)
                    claimHistoryItem.ClaimDetails = new List<ClaimDetailItem>();
                if (claimDetailItems != null)
                    claimHistoryItem.ClaimDetails.Add(claimDetailItems);
                return claimHistoryItem;
            }, new { patientId }, splitOn: "Id");

            var Claims = claims.Values.ToList();
            Claims.ForEach(x => x.LineCount = x.ClaimDetails.Count);
            return Claims;
        }

        /// <summary>
        /// Gets the remit history items with details
        /// </summary>
        /// <param name="patientId">the patient id</param>
        /// <param name="conn">the connection to be used for query</param>
        /// <returns>the list of remit history items</returns>
        private List<RemitHistoryItem> GetRemits(int patientId, IDbConnection conn)
        {
            var remits = new Dictionary<int, RemitHistoryItem>();
            conn.Query<RemitHistoryItem, RemitDetailItem, RemitHistoryItem>(GetRemitsHistorySql, (remitItems, remitDetailItems) =>
            {
                if (!remits.TryGetValue(remitItems.Id, out RemitHistoryItem remitHistoryItem))
                    remits.Add(remitItems.Id, remitHistoryItem = remitItems);
                if (remitHistoryItem.RemitDetails == null)
                    remitHistoryItem.RemitDetails = new List<RemitDetailItem>();
                if (remitDetailItems != null)
                    remitHistoryItem.RemitDetails.Add(remitDetailItems);
                return remitHistoryItem;
            }, new { patientId }, splitOn: "Id");

            var Remits = remits.Values.ToList();
            return Remits;
        }
    }
}
