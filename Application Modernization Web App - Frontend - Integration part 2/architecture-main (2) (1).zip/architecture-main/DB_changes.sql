--	Correcting table schema & default data for RevCPTDetail table.
DROP TABLE IF EXISTS RevCPTDetail
GO

CREATE TABLE RevCPTDetail ( [PatientRevenueId] int, [patientid] int, [RevenueCode] varchar(100), [RevCodeDescription] varchar(255), [RevCodeId] int, [RevCodeTransId] varchar(155), [RevServiceDate] datetime, [RevUnits] decimal(11,3), [RevCharges] money, [RevDeniedCharges] money, [RevExcludedCharges] money, [RevNonBilledCharges] money, [RevCost] money, [PatientCPTId] int, [CPTCode] varchar(9), [CPTDescr] varchar(255), [Mod1] varchar(10), [CPTRevCode] varchar(30), [ServiceDate] datetime, [Units] decimal(11,3), [Charges] money, [Rate] int, [ExpectedReimburse] int, [Service] int, [Method] int, [PPC] int, [Terms] int, [SurgOrder] int, [ExcludedCharges] money, [NonBilledCharges] money, [DeniedCharges] money, [Cost] money, [Mod2] varchar(10), [CPTTransId] varchar(155), [ServiceType] varchar(1), [PhysicianID] varchar(100), [PhysicianCodeLink] int, [ServiceLocation] varchar(10), [PrimaryDeniedCharges] money, [P1ActiveDenialReasonCodes] varchar(max), [P1ActiveDenialRemarkCodes] varchar(max), [BillingProviderNPI] varchar(10), [ICD9D] varchar(10), [ICD9D_2] varchar(10), [ICD9D_3] varchar(10), [ICD9D_4] varchar(10), [ICD9D_5] varchar(10), [ICDRevisionNumber] int )
INSERT INTO RevCPTDetail
VALUES
( 8141768, 1, '0320', 'Radiology - Diagnostic', 16145, '032071020PDH20161025', N'2016-10-25T00:00:00', 1.000, 360.0000, 0.0000, 0.0000, 0.0000, 0.0000, 9470504, '71020', 'Chest x-ray 2vw frontal&latl', 'PD', '0320', N'2016-10-25T00:00:00', 1.000, 360.0000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.0000, 0.0000, 0.0000, 0.0000, NULL, '032071020PDH20161025', 'H', '', 0, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL ), 
( 8141769, 1, '0730', 'EKG/ECG', 16344, '073093005PDH20161025', N'2016-10-25T00:00:00', 1.000, 635.0000, 0.0000, 0.0000, 0.0000, 0.0000, 9470505, '93005', 'Electrocardiogram tracing', 'PD', '0730', N'2016-10-25T00:00:00', 1.000, 635.0000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.0000, 0.0000, 0.0000, 0.0000, NULL, '073093005PDH20161025', 'H', '', 0, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL )
GO

--	Correction for data stored in tblDetailReimb table to follow the pattern being used in all other detail tables.
--	For this project any patient detail can be hard-coded to use PatientID = 1 or the data can be replicated to match the key our system uses with is for it to match tblWorklistData.PatientID
UPDATE	tblDetailReimb
SET		PatientID = 1
GO

--	Correction for tblICDCodeDetail schema to include the PatientID for correct lookups.
IF NOT EXISTS ( SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[tblICDCodeDetail]') AND name = 'PatientID')
BEGIN
	ALTER TABLE tblICDCodeDetail ADD PatientID INT
END
GO

--	Adding default value of 1 which is being used for all detail data examples for this project.
UPDATE	tblICDCodeDetail
SET		PatientID = 1
GO

--	Corrections for ClaimHistory table to match UI requirements.
IF NOT EXISTS ( SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[ClaimHistory]') AND name = 'PrimaryPayer')
BEGIN
	ALTER TABLE dbo.ClaimHistory ADD PrimaryPayer VARCHAR(100)
END
GO

IF NOT EXISTS ( SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[ClaimHistory]') AND name = 'DestinationPayer')
BEGIN
	ALTER TABLE dbo.ClaimHistory ADD DestinationPayer VARCHAR(100)
END
GO

IF NOT EXISTS ( SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[ClaimHistory]') AND name = 'DestinationPayerResp')
BEGIN
	ALTER TABLE dbo.ClaimHistory ADD DestinationPayerResp VARCHAR(100)
END
GO

IF NOT EXISTS ( SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[ClaimHistory]') AND name = 'ClaimFreqType')
BEGIN
	ALTER TABLE dbo.ClaimHistory ADD ClaimFreqType VARCHAR(100)
END
GO

UPDATE	ClaimHistory
SET		PrimaryPayer = 'Payer Name',
		DestinationPayer = 'Other Payer Name',
		DestinationPayerResp = 'Primary',
		ClaimFreqType = 'Admit thru Discharge'
GO

--	Modification to ClaimDetail table to match UI requirements
IF NOT EXISTS ( SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[ClaimDetail]') AND name = 'Modifier')
BEGIN
	ALTER TABLE dbo.ClaimDetail ADD Modifier VARCHAR(100)
END
GO

UPDATE	ClaimDetail
SET		Modifier = '00'
GO

--	Add missing field to detail table.
ALTER TABLE tblPaymentDetail ADD PatientID INT NULL
GO

--	Populate the missing data for the example account provided in initial database.
UPDATE	tblPaymentDetail
SET		PatientID = 1
FROM	tblPaymentDetail
WHERE	PatientID IS NULL
GO

