# architecture

The docs file are shared on [Google drive](https://drive.google.com/drive/folders/1Y1kAErRhpykKze5yJU_S9BNSZrfG3XCS?usp=sharing)

## Database Setup

1. Run `DBCreateScript.sql` 
1. Run `DB_changes.sql` to make changes on the database.

## API Details
1. `swagger.json` has the API design
1. `implementation Guides/*` has the markdown file in which each file represents a controller and provides the detail on how to implement each API
1. Overall architecture detail is shared on this [docs](https://docs.google.com/document/d/1uBbqY_8saNRy0s6xMbxFj9j5E82j5LRh/edit?usp=sharing)
1. API to UI mapping document is [here](https://docs.google.com/document/d/1QKIV2geZCc9-eOo5ysb0ztUV14LWJn8u/edit?usp=sharing)
