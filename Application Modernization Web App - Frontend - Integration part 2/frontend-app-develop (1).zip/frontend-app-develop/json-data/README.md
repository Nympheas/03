# Local Deploy

run

```
npm i
npm start
```

the api server should be accessible at `http://localhost:3000`

```
you might need update `apiBase` environment configuration of the `prototype` app to point to this heroku app
```
