export class UserModel {
  id = 0;
  username = '';
  password = '';
}
