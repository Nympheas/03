export interface SystemValueModel {
  code: number;
  description: string;
}
