export interface LoginFormModel {
  username: string;
  password: string;
  serverName: string;
  databaseName: string;
}
