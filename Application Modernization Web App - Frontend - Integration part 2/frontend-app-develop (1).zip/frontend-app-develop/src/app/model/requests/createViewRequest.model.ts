export interface CreateViewRequestModel {
  description: string;
  isDefault: boolean;
  limits: {
    auditor: number;
    followUp: number;
    status: number;
    accountAge: number;
    hiddenRecords: number;
  };
  name: string;
}
