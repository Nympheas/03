import { CreateViewResponseModel } from './createViewResponse.model';

export type GetViewsResponseModel = CreateViewResponseModel[];
