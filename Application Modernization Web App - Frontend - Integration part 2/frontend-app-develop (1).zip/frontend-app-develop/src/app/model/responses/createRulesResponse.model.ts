import { RuleResponse } from './getRulesResponse.model';

export type CreateRulesResponseModel = RuleResponse[];
