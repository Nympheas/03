export interface GetDefaultViewLimitsResponseModel {
  auditor: number;
  followUp: number;
  status: number;
  accountAge: number;
  hiddenRecords: number;
}
