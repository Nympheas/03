export interface LoginResponseModel {
  token: string;
}
