import { TableModel } from './table.model';

export interface TableOptionActionModel {
  action: string;
  data: TableModel;
}
