import { Component, Input, EventEmitter, Output } from '@angular/core';

/**
 * This class represents the lazy loaded MyWorklistMenuComponent.
 */
@Component({
  selector: 'app-sd-my-worklist-menu',
  templateUrl: 'my-worklist-menu.component.html',
  styleUrls: ['my-worklist-menu.component.scss']
})
export class MyWorklistMenuComponent {
  @Input() menuCollapsed = false;
  @Input() hasSelectedAccounts = false;
  @Input() isShownResearch = false;
  @Output() clickMenu: EventEmitter<any> = new EventEmitter();
  @Output() toggleResearch: EventEmitter<any> = new EventEmitter();
  @Output() clickMenuOptions: EventEmitter<string> = new EventEmitter();
  @Output() clickLogout: EventEmitter<void> = new EventEmitter();

  isOpenedModify = false;
  isOpenedAction = false;
  isOpenedSearch = false;
  isOpenedHelp = false;

  searchType = 'Patient Number';
  searchText = '';

  viewDropdown = '[My Last Quick Search]';
  typeDropdown = 'Default';
  layoutsDropdown = 'Default';

  viewOptions = ['[My Last Quick Search]', 'Option 2', 'Option 3'];
  typeOptions = ['Summary', 'Detail'];
  layoutsOptions = ['Default', 'Option 2', 'Option 3'];

  // click Modify
  clickModify(): void {
    this.isOpenedModify = !this.isOpenedModify;
  }

  // click Action
  clickAction(): void {
    this.isOpenedAction = !this.isOpenedAction;
  }

  // click Search
  clickSearch(): void {
    this.isOpenedSearch = !this.isOpenedSearch;
  }

  // click Help
  clickHelp(): void {
    this.isOpenedHelp = !this.isOpenedHelp;
  }
}
