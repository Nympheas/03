import { Component, Input } from '@angular/core';
import { TableModel } from '../../../model/table.model';

/**
 * This class represents the lazy loaded TabClaimsHistoryComponent.
 */
@Component({
  selector: 'app-sd-tab-claims-history',
  templateUrl: 'tab-claims-history.component.html',
  styleUrls: ['tab-claims-history.component.scss']
})
export class TabClaimsHistoryComponent {
  @Input() dataListClaims: TableModel[] = [];
  @Input() dataListRemits: TableModel[] = [];
}
