import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { DataListMyWorklistResearchService } from '../../../shared/services/data-list-my-worklist-research.service';
import { TableModel } from '../../../model/table.model';

/**
 * This class represents the lazy loaded ModalWindowsPaymentDetailComponent.
 */
@Component({
  selector: 'app-sd-modal-windows-payment-detail',
  templateUrl: 'modal-windows-payment-detail.component.html',
  styleUrls: ['modal-windows-payment-detail.component.scss']
})
export class ModalWindowsPaymentDetailComponent implements OnInit {
  @Input() modalData = {
    name: ''
  };

  @Input() paidBy = [] as string[];
  @Input() paymentType = [] as string[];

  @Output() clickDeletePayment: EventEmitter<any> = new EventEmitter();
  @Output() closeModalWindow: EventEmitter<boolean> = new EventEmitter();

  paidBySelection = '';
  paymentTypeSelection = '';

  dataList: TableModel[] = [];

  /**
   * Creates an instance of the ModalWindowsPaymentDetailComponent with the injected
   * DataListService.
   */
  constructor(public dataListService: DataListMyWorklistResearchService) {}

  /**
   * OnInit
   */
  ngOnInit(): void {
    this.dataListService.getMyWorklistResearchPaymentAdjustmentsTabPaymentDetailsData().subscribe((data) => {
      this.dataList = data;

      this.updateFilter();
    });

    this.paidBySelection = this.paidBy[0];

    this.paymentTypeSelection = this.paymentType[0];
  }

  // update Filter
  updateFilter(): void {
    this.dataList.forEach((item, index) => {
      let matched = true;
      if (item.fieldList[0].fieldValue !== this.paidBySelection) {
        matched = false;
      }

      if (this.paymentTypeSelection !== 'All') {
        if (item.fieldList[1].fieldValue !== this.paymentTypeSelection) {
          matched = false;
        }
      }

      item.hidden = !matched;
    });
  }

  // is Form Valid
  isFormValid(): boolean {
    return true;
  }

  /**
   * close Modal
   */
  closeModal(isSave: boolean): void {
    this.closeModalWindow.emit(isSave);
  }

  /**
   * selected Row Number
   */
  selectedRowNumber(): number {
    let selectedNumber = 0; // 0
    this.dataList.forEach((item, index) => {
      if (item.checked) {
        selectedNumber++;
      }
    });

    return selectedNumber;
  }
}
