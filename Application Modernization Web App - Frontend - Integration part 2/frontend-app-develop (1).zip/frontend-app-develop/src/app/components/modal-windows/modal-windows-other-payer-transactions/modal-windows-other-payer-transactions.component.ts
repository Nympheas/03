import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { DataListMyWorklistResearchService } from '../../../shared/services/data-list-my-worklist-research.service';
import { TableModel } from '../../../model/table.model';
import { TransactionFileTypeDropdownOptions } from '../../../../config/configuration';

/**
 * This class represents the lazy loaded ModalWindowsOtherPayerTransactionsComponent.
 */
@Component({
  selector: 'app-sd-modal-windows-other-payer-transactions',
  templateUrl: 'modal-windows-other-payer-transactions.component.html',
  styleUrls: ['modal-windows-other-payer-transactions.component.scss']
})
export class ModalWindowsOtherPayerTransactionsComponent implements OnInit {
  @Input() modalData = {
    name: ''
  };

  @Output() clickDeleteTransactions: EventEmitter<any> = new EventEmitter();
  @Output() clickCommitTransactions: EventEmitter<any> = new EventEmitter();
  @Output() closeModalWindow: EventEmitter<boolean> = new EventEmitter();

  transactionFileTypeDropdownOptions = TransactionFileTypeDropdownOptions;

  transactionFileTypeSelection = '';

  dataList: TableModel[] = [];

  /**
   * Creates an instance of the ModalWindowsOtherPayerTransactionsComponent with the injected
   * DataListService.
   */
  constructor(public dataListService: DataListMyWorklistResearchService) {}

  /**
   * OnInit
   */
  ngOnInit(): void {
    this.dataListService.getMyWorklistResearchPaymentAdjustmentsTabOtherPayerTransactionsData().subscribe((data) => {
      this.dataList = data;

      this.updateFilter();
    });

    this.transactionFileTypeSelection = this.transactionFileTypeDropdownOptions[0];
  }

  // update Filter
  updateFilter(): void {
    this.dataList.forEach((item, index) => {
      let matched = true;
      if (item.fieldList[9].fieldValue !== this.transactionFileTypeSelection) {
        matched = false;
      }

      item.hidden = !matched;
    });
  }

  // is Form Valid
  isFormValid(): boolean {
    return true;
  }

  /**
   * close Modal
   */
  closeModal(isSave: boolean): void {
    this.closeModalWindow.emit(isSave);
  }

  /**
   * selected Row Number
   */
  selectedRowNumber(): number {
    let selectedNumber = 0; // 0
    this.dataList.forEach((item, index) => {
      if (item.checked) {
        selectedNumber++;
      }
    });

    return selectedNumber;
  }
}
