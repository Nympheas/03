import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { DataListMyWorklistResearchService } from '../../shared/services/data-list-my-worklist-research.service';
import { TableModel } from '../../model/table.model';
import { TableOptionActionModel } from '../../model/tableOptionAction.model';
import { ResearchTabArray } from '../../../config/configuration';
import * as _ from 'lodash';

/**
 * This class represents the lazy loaded MyWorklistResearchComponent.
 */
@Component({
  selector: 'app-sd-my-worklist-research',
  templateUrl: 'my-worklist-research.component.html',
  styleUrls: ['my-worklist-research.component.scss']
})
export class MyWorklistResearchComponent implements OnInit {
  @Input() researchTabIndex = 0;
  @Input() dataListLookups: any = {};

  @Output() clickTab: EventEmitter<number> = new EventEmitter();

  dataListResearchAuditStatusHistoryTab: TableModel[] = [];
  dataListResearchChargeCodeDetailTab: TableModel[] = [];
  dataListResearchClaimsHistoryTabClaims: TableModel[] = [];
  dataListResearchClaimsHistoryTabRemits: TableModel[] = [];
  dataListResearchDetailReimbTab: TableModel[] = [];
  dataListResearchIcdCodesTab: TableModel[] = [];
  dataListResearchPaymentAdjustmentsTab: TableModel[] = [];
  dataListResearchProfessionalClaimsTab: TableModel[] = [];
  dataListResearchRevCPTDetailTab: TableModel[] = [];

  dataListDetails: TableModel = {
    id: 0,
    fieldList: [],
    expandData: null,
    checked: false,
    hidden: false
  };

  modalData = {
    name: '' // 'modal-windows-payment-detail', 'modal-windows-other-payer-transactions'
  };
  confirmModalData = {
    title: '',
    description: '',
    sourceModal: ''
  };

  researchTabArray = ResearchTabArray;

  /**
   * Creates an instance of the MyWorklistPageComponent with the injected
   * DataListService.
   */
  constructor(public dataListService: DataListMyWorklistResearchService) {}

  /**
   * OnInit
   */
  ngOnInit(): void {
    this.dataListService.getMyWorklistResearchAuditStatusHistoryTabData().subscribe((data: TableModel[]) => {
      this.dataListResearchAuditStatusHistoryTab = data;
    });

    this.dataListService.getMyWorklistResearchChargeCodeDetailTabData().subscribe((data: TableModel[]) => {
      this.dataListResearchChargeCodeDetailTab = data;
    });

    this.dataListService.getMyWorklistResearchClaimsHistoryTabClaimsData().subscribe((data: TableModel[]) => {
      this.dataListResearchClaimsHistoryTabClaims = data;
    });

    this.dataListService.getMyWorklistResearchClaimsHistoryTabRemitsData().subscribe((data: TableModel[]) => {
      this.dataListResearchClaimsHistoryTabRemits = data;
    });

    this.dataListService.getMyWorklistResearchDetailReimbTabData().subscribe((data: TableModel[]) => {
      this.dataListResearchDetailReimbTab = data;
    });

    this.dataListService.getMyWorklistResearchIcdCodesTabData().subscribe((data: TableModel[]) => {
      this.dataListResearchIcdCodesTab = data;
    });

    this.dataListService.getMyWorklistResearchPaymentAdjustmentsTabData().subscribe((data: TableModel[]) => {
      this.dataListResearchPaymentAdjustmentsTab = data;
    });

    this.dataListService.getMyWorklistResearchProfessionalClaimsTabData().subscribe((data: TableModel[]) => {
      this.dataListResearchProfessionalClaimsTab = data;
    });

    this.dataListService.getMyWorklistResearchRevCPTDetailTabData().subscribe((data: TableModel[]) => {
      this.dataListResearchRevCPTDetailTab = data;
    });
  }

  /**
   * click Prev arrow
   */
  clickPrev(): void {
    this.clickTab.emit(this.researchTabIndex - 1);
  }

  /**
   * click Next arrow
   */
  clickNext(): void {
    this.clickTab.emit(this.researchTabIndex + 1);
  }

  // click Table Options
  clickTableOptions(event: TableOptionActionModel): void {
    switch (event.action) {
      case 'Add Revenue/CPT':
        this.modalData.name = 'modal-windows-add-revenue-cpt';
        break;
      case 'Remove Revenue/CPT':
        this.modalData['name'] = 'modal-windows-confirm';
        this.confirmModalData = {
          title: 'Delete Confirmation',
          description: 'Are you sure you want to remove the record?',
          sourceModal: ''
        };
        break;
      case 'Combined Rev/CPT Code Details':
        this.modalData.name = 'modal-windows-combined-rev-cpt-code-details';
        break;
      case 'Add Charge Code':
        this.modalData.name = 'modal-windows-add-charge-code';
        break;
      case 'Remove Charge Code':
        this.modalData['name'] = 'modal-windows-confirm';
        this.confirmModalData = {
          title: 'Delete Confirmation',
          description: 'Are you sure you want to remove the record?',
          sourceModal: ''
        };
        break;
      case 'Payment Detail':
        this.modalData.name = 'modal-windows-payment-detail';
        break;
      case 'Other Payer Transactions':
        this.modalData.name = 'modal-windows-other-payer-transactions';
        break;
      case 'ICD Code Details':
        this.modalData.name = 'modal-windows-icd-code-details';
        break;
      case 'Payment Details Popup':
        this.modalData.name = 'modal-windows-payment-detail';
        break;
      case 'Other Payer Popup':
        this.modalData.name = 'modal-windows-other-payer-transactions';
        break;
      default:
        break;
    }
  }

  // click Delete Transactions
  clickDeleteTransactions(event: any): void {
    this.modalData['name'] = 'modal-windows-confirm';
    this.confirmModalData = {
      title: 'Delete Confirmation',
      description: 'Are you sure you want to remove the transaction?',
      sourceModal: 'modal-windows-other-payer-transactions'
    };
  }

  // click Commit Transactions
  clickCommitTransactions(event: any): void {
    this.modalData['name'] = 'modal-windows-confirm';
    this.confirmModalData = {
      title: 'Commit Transaction',
      description: 'Are you sure you want to commit the transaction?',
      sourceModal: 'modal-windows-other-payer-transactions'
    };
  }

  // click Delete Payment
  clickDeletePayment(event: any): void {
    this.modalData['name'] = 'modal-windows-confirm';
    this.confirmModalData = {
      title: 'Delete Confirmation',
      description: 'Are you sure you want to remove the payment?',
      sourceModal: 'modal-windows-payment-detail'
    };
  }

  // show Rev CPT Detail Modal
  showRevCPTDetailModal(dataListTab: TableModel[], rowIndex: number): void {
    this.modalData['name'] = 'modal-windows-combined-rev-cpt-code-details';
    this.dataListDetails = _.cloneDeep(dataListTab[rowIndex]);
  }

  // show Charge Code Detail Modal
  showChargeCodeDetailModal(dataListTab: TableModel[], rowIndex: number): void {
    this.modalData['name'] = 'modal-windows-charge-code-details';
    this.dataListDetails = _.cloneDeep(dataListTab[rowIndex]);
  }

  // show Icd Codes Detail Modal
  showIcdCodesDetailModal(dataListTab: TableModel[], rowIndex: number): void {
    this.modalData['name'] = 'modal-windows-icd-code-details';
    this.dataListDetails = _.cloneDeep(dataListTab[rowIndex]);
  }

  /**
   * close Modal Window
   */
  closeModalWindow(isSave: boolean, modalName: string): void {
    if (isSave) {
      switch (modalName) {
        case 'modal-windows-confirm':
          this.modalData['name'] = this.confirmModalData.sourceModal;
          break;
        default:
          this.modalData['name'] = '';
          break;
      }
    } else {
      switch (modalName) {
        case 'modal-windows-confirm':
          this.modalData['name'] = this.confirmModalData.sourceModal;
          break;
        default:
          this.modalData['name'] = '';
          break;
      }
    }
  }
}
