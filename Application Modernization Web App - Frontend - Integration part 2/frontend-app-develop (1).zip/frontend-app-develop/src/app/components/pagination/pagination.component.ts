import { Component, Input, EventEmitter, Output } from '@angular/core';

/**
 * This class represents the lazy loaded PaginationComponent.
 */
@Component({
  selector: 'app-sd-pagination',
  templateUrl: 'pagination.component.html',
  styleUrls: ['pagination.component.scss']
})
export class PaginationComponent {
  @Input() pagePerNumberDropdownOptions: string[] = [];
  @Input() pageData = {
    pagePerNumber: '', // row number per page
    pageIndex: 0, // current page index
    totalPage: 0, // total number of pages
    totalRow: 0, // total number of rows
    pagerLinks: [0, 1, 2] // array of page links
  };

  @Output() changePagination: EventEmitter<any> = new EventEmitter();

  /**
   * click Prev arrow
   */
  clickPrev(): void {
    this.pageData.pageIndex--;
    this.changePagination.emit(this.pageData);
  }

  /**
   * click Page Number Link
   * @param index clicked page index
   */
  clickPageLink(index: number): void {
    this.pageData.pageIndex = index;
    this.changePagination.emit(this.pageData);
  }

  /**
   * click Next arrow
   */
  clickNext(): void {
    this.pageData.pageIndex++;
    this.changePagination.emit(this.pageData);
  }

  // change Dropdown
  changeDropdown(event: string): void {
    this.pageData.pagePerNumber = event;
    this.changePagination.emit(this.pageData);
  }
}
