import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { LimitsDropdownOptions } from '../../../config/configuration';
import {
  MyWorklistColumnSettingsModel,
  MyWorklistColumnSettingsSubSettingsModel
} from '../../model/myWorklistColumnSettings.model';
import * as _ from 'lodash';

/**
 * This class represents the lazy loaded MyWorklistMenuSecondaryComponent.
 */
@Component({
  selector: 'app-sd-my-worklist-menu-secondary',
  templateUrl: 'my-worklist-menu-secondary.component.html',
  styleUrls: ['my-worklist-menu-secondary.component.scss']
})
export class MyWorklistMenuSecondaryComponent implements OnInit {
  @Input() dataListColumnSettings = [] as MyWorklistColumnSettingsModel[];

  @Output() clickSaveColumnSettings: EventEmitter<MyWorklistColumnSettingsSubSettingsModel[]> = new EventEmitter();

  dataListColumnSettingsShown = [] as MyWorklistColumnSettingsModel[];

  configureIndex = 0;
  configureIndexShown = 0;

  fieldSelectionIndex = -1;

  isOpened = false;

  auditor = LimitsDropdownOptions[0];
  followUp = LimitsDropdownOptions[0];
  status = LimitsDropdownOptions[0];
  accountAge = LimitsDropdownOptions[0];
  hiddenRecords = LimitsDropdownOptions[0];

  columnConfiguration?: MyWorklistColumnSettingsModel;

  auditorOptions = LimitsDropdownOptions;
  followUpOptions = LimitsDropdownOptions;
  statusOptions = LimitsDropdownOptions;
  accountAgeOptions = LimitsDropdownOptions;
  hiddenRecordsOptions = LimitsDropdownOptions;

  /**
   * OnInit
   */
  ngOnInit(): void {
    this.configureIndexShown = this.configureIndex;
    this.dataListColumnSettingsShown = _.cloneDeep(this.dataListColumnSettings);
    this.columnConfiguration = this.dataListColumnSettings[this.configureIndexShown];
  }

  // click Manage Column
  clickManageColumn(isSave: boolean): void {
    this.isOpened = !this.isOpened;

    if (this.isOpened) {
      this.configureIndexShown = this.configureIndex;
      this.dataListColumnSettingsShown = _.cloneDeep(this.dataListColumnSettings);
      this.columnConfiguration = this.dataListColumnSettings[this.configureIndexShown];
    }

    if (isSave) {
      this.configureIndex = this.configureIndexShown;
      this.dataListColumnSettings = _.cloneDeep(this.dataListColumnSettingsShown);

      this.clickSaveColumnSettings.emit(this.dataListColumnSettingsShown[this.configureIndexShown].settings);
    }
  }

  // update ConfigureIndex
  updateConfigureIndex(): void {
    let newIndex = 0;
    this.dataListColumnSettingsShown.forEach((item, index) => {
      if (this.columnConfiguration?.configureName === item.configureName) {
        newIndex = index;
      }
    });
    this.fieldSelectionIndex = -1;
    this.configureIndexShown = newIndex;
  }

  // click Up Arrow
  clickUpArrow(): void {
    const columnSettingsTemp = _.cloneDeep(this.dataListColumnSettingsShown[this.configureIndexShown].settings);

    const newSettings = columnSettingsTemp
      .slice(0, this.fieldSelectionIndex - 1)
      .concat(columnSettingsTemp[this.fieldSelectionIndex])
      .concat(columnSettingsTemp[this.fieldSelectionIndex - 1])
      .concat(columnSettingsTemp.slice(this.fieldSelectionIndex + 1));

    this.fieldSelectionIndex--;
    this.dataListColumnSettingsShown[this.configureIndexShown].settings = newSettings;
  }

  // click Down Arrow
  clickDownArrow(): void {
    const columnSettingsTemp = _.cloneDeep(this.dataListColumnSettingsShown[this.configureIndexShown].settings);

    const newSettings = columnSettingsTemp
      .slice(0, this.fieldSelectionIndex)
      .concat(columnSettingsTemp[this.fieldSelectionIndex + 1])
      .concat(columnSettingsTemp[this.fieldSelectionIndex])
      .concat(columnSettingsTemp.slice(this.fieldSelectionIndex + 2));

    this.fieldSelectionIndex++;
    this.dataListColumnSettingsShown[this.configureIndexShown].settings = newSettings;
  }
}
