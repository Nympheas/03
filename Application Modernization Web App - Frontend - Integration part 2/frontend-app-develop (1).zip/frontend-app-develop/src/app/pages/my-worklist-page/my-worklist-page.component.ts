import { Component, OnInit } from '@angular/core';
import { DataListService } from '../../shared/services/data-list.service';
import { AuthService } from '../../shared/services/auth.service';
import { MyWorklistColumnSettingsModel } from '../../model/myWorklistColumnSettings.model';
import { TableModel } from '../../model/table.model';
import { PagePerNumberMyWorklistDropdownOptions } from '../../../config/configuration';
import { MyWorklistColumnSettingsSubSettingsModel } from '../../model/myWorklistColumnSettings.model';
import * as _ from 'lodash';

/**
 * This class represents the lazy loaded MyWorkListPageComponent.
 */
@Component({
  selector: 'app-sd-my-worklist-page',
  templateUrl: 'my-worklist-page.component.html',
  styleUrls: ['my-worklist-page.component.scss']
})
export class MyWorklistPageComponent implements OnInit {
  dataList: TableModel[] = [];
  dataListShown: TableModel[] = [];
  dataListColumnSettings: MyWorklistColumnSettingsModel[] = [];
  dataListLookups: any = {};

  sortData = {
    sortColumn: 'Patient Name',
    sortOrder: 'asc' // 'asc', 'desc'
  };
  pageData = {
    pagePerNumber: '500 per page', // row number per page
    pageIndex: 0, // current page index
    totalPage: 2, // total number of pages
    totalRow: 0, // total number of rows
    pagerLinks: [0, 1] // array of page links
  };
  pagePerNumberDropdownOptions = PagePerNumberMyWorklistDropdownOptions;

  modalData = {
    name: '' // ''
  };
  confirmModalData = {
    title: '',
    description: '',
    sourceModal: ''
  };

  menuCollapsed = false;
  collapsedDraggableLine = false;

  isShownResearch = true;
  researchTabIndex = 0; // 10

  /**
   * Creates an instance of the MyWorklistPageComponent with the injected
   * DataListService.
   */
  constructor(public dataListService: DataListService, private authService: AuthService) {}

  /**
   * OnInit
   */
  ngOnInit(): void {
    this.dataListService.getMyWorklistData(null).subscribe((data) => {
      this.dataList = data;
      this.dataListShown = _.cloneDeep(this.dataList);
    });

    this.dataListService.getMyWorklistColumnSettingsData().subscribe((data) => {
      this.dataListColumnSettings = data;
    });

    this.dataListService.getLookupsData().subscribe((data) => {
      this.dataListLookups = data;
    });
  }

  // click Save Column Settings
  clickSaveColumnSettings(columnSettingsData: MyWorklistColumnSettingsSubSettingsModel[]): void {
    // mockup to show the changed column setting in table
    this.dataListShown.forEach((item, index) => {
      item.fieldList = [];
    });

    if (this.dataList.length > 0) {
      columnSettingsData.forEach((columnItem, columnIndex) => {
        if (columnItem.isShown) {
          let matchedIndex = 0;
          this.dataList[0].fieldList.forEach((item, index) => {
            if (columnItem.fieldName === item.fieldName) {
              matchedIndex = index;
            }
          });

          this.dataList.forEach((item, index) => {
            this.dataListShown[index].fieldList.push(item.fieldList[matchedIndex]);
          });
        }
      });
    }
  }

  /**
   * click Menu
   */
  clickMenu(): void {
    this.menuCollapsed = !this.menuCollapsed;
  }

  // click Menu Options
  clickMenuOptions(optionName: string): void {
    switch (optionName) {
      case 'Create Simulation DataSet':
        this.modalData.name = 'modal-windows-create-simulator-dataset';
        break;
      case 'Create New Account':
        this.modalData.name = 'modal-windows-add-patient-account';
        break;
      case 'View Contact Information':
        this.modalData.name = 'modal-windows-contact-information';
        break;
      default:
        break;
    }
  }

  /**
   * close Modal Window
   */
  closeModalWindow(isSave: boolean, modalName: string): void {
    if (isSave) {
      switch (modalName) {
        case 'modal-windows-contact-information':
          this.modalData['name'] = 'modal-windows-confirm';
          this.confirmModalData = {
            title: 'Action Complete - Reapply View',
            description: 'Would you like your view reapplied?',
            sourceModal: 'modal-windows-contact-information'
          };
          break;
        case 'modal-windows-confirm':
          this.modalData['name'] = '';
          break;
        default:
          this.modalData['name'] = '';
          break;
      }
    } else {
      switch (modalName) {
        case 'modal-windows-confirm':
          this.modalData['name'] = this.confirmModalData.sourceModal;
          break;
        default:
          this.modalData['name'] = '';
          break;
      }
    }
  }

  // clickDraggableLine
  clickDraggableLine(): void {
    this.collapsedDraggableLine = !this.collapsedDraggableLine;
  }

  /**
   * chang Pagination
   */
  changePagination(event: any): void {
    console.log(event);
  }

  /**
   * change Sort
   */
  changeSort(event: any): void {
    console.log(event);
  }

  /**
   * selected Row Number
   */
  selectedRowNumber(): number {
    let selectedNumber = 0; // 0
    this.dataListShown.forEach((item, index) => {
      if (item.checked) {
        selectedNumber++;
      }
    });

    return selectedNumber;
  }

  /**
   * logout
   */
  clickLogout(): void {
    this.authService.logout();
  }
}
