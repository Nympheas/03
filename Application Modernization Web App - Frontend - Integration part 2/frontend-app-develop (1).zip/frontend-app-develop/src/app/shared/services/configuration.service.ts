import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { GetDefaultViewLimitsResponseModel } from '../../model/responses/getDefaultViewLimitsResponse.model';

@Injectable()
export class ConfigurationService {
  private apiBase = environment.apiBase; // URL to web api

  constructor(protected httpClient: HttpClient) {}

  /**
   * get default limit settings
   * @returns default limit settings
   */
  public getDefaultViewLimits(): Observable<GetDefaultViewLimitsResponseModel> {
    return this.httpClient
      .get<GetDefaultViewLimitsResponseModel>(this.apiBase + 'configuration/defaultViewLimits')
      .pipe(take(1));
  }
}
