import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Injectable } from '@angular/core';
import { isNumber, padNumber } from './util';

@Injectable()
export class NgbDateConversion {
  formatToStr(date: NgbDateStruct): string {
    return date
      ? `${isNumber(date.month) ? padNumber(date.month) : ''}/${isNumber(date.day) ? padNumber(date.day) : ''}/${
          date.year
        }`
      : '';
  }

  formatToDate(dateStr: string): NgbDateStruct {
    if (dateStr === '') {
      return {
        day: 0,
        month: 0,
        year: 0
      };
    } else {
      const str = dateStr.split('/');
      return {
        day: parseInt(str[1], 10),
        month: parseInt(str[0], 10),
        year: parseInt(str[2], 10)
      };
    }
  }
}
