export const ResearchTabArray = [
  'Rev/CPT Detail',
  'Charge Code Detail',
  'Claims History',
  'Professional Claims',
  'Payment & Adjustments',
  'ICD Codes',
  'Special Care',
  'Codes',
  'HIPPS Codes',
  'Billing Indicators',
  'EOR',
  'Detail Reimb',
  'Physicians',
  'UR Authorizations',
  'Patient Account Notes',
  'Audit Status History',
  'View Rules',
  'Action History',
  'Invoice Detail'
];

export const LimitsDropdownOptions = ['All Records', 'Exclude', 'Include All'];

export const PagePerNumberViewAdministrationDropdownOptions = ['15 per page', '50 per page', '100 per page'];

export const PagePerNumberMyWorklistDropdownOptions = ['500 per page', '1,000 per page', '10,000 per page'];

export const CostDropdownOptions = ['Between', 'Equal To', 'Greater Than', 'Less Than'];

export const DateDropdownOptions = ['Date Range'];

export const DateTimeDropdownOptions = ['Date Time Range'];

export const TimeHourDropdownOptions = [
  '00:00 am',
  '01:00 am',
  '02:00 am',
  '03:00 am',
  '04:00 am',
  '05:00 am',
  '06:00 am',
  '07:00 am',
  '08:00 am',
  '09:00 am',
  '10:00 am',
  '11:00 am',
  '12:00 am',
  '01:00 pm',
  '02:00 pm',
  '03:00 pm',
  '04:00 pm',
  '05:00 pm',
  '06:00 pm',
  '07:00 pm',
  '08:00 pm',
  '09:00 pm',
  '10:00 pm',
  '11:00 pm'
];

export const PercentDropdownOptions = ['Between', 'Equal To', 'Greater Than', 'Less Than'];

export const TextNameLeftDropdownOptions = ['Begins with', 'Ends with', 'Contains'];

export const TextNameRightDropdownOptions = ['Single value', 'Between'];

export const TextStateLeftDropdownOptions = ['Multi-select'];

export const TextStateRightDropdownOptions = ['Include Selected Value', 'Exclude Selected Value'];

export const StateOptions = [
  'California',
  'New York',
  'Indiana',
  'New Delhi',
  'Colorado',
  'Connecticut',
  'Delaware',
  'Georgia'
];

export const SexOptions = ['Male', 'Female', 'Unknown'];

export const MaritalStatusDropdownOptions = ['Married', 'Unmarried'];

export const EmployerDropdownOptions = ['Acme', 'Option 1', 'Option 2'];

export const ServiceTypeDropdownOptions = ['H', 'M', 'L'];

export const PointOfServiceDropdownOptions = ['Option 1', 'Option 2'];

export const AuditStatusDropdownOptions = ['Pending', 'Closed'];

export const ContactTypeDropdownOptions = [' Automated Variable', 'Option 1', 'Option 2'];

export const TransactionFileTypeDropdownOptions = [
  'Inpatient Payment',
  'Outpatient Payment',
  'Combined Inpat/Outpat Payments',
  'Combined Inpat/Outpat Claim Adjustment File'
];

export const PayerIDDropdownOptions = ['P123', 'P456', 'P789'];

export const PublicEndpoints = ['auth/login'];

export const Roles = {
  siteAdmin: 'Site Admin',
  accountManagement: 'Account Management'
};

export const DateFormat = 'MM/DD/YYYY';
