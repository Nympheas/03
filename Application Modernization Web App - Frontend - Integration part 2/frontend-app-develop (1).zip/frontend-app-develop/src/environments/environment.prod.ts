export const environment = {
  production: true,
  apiBase: 'https://pmmc-mock-api.azurewebsites.net/',
  mockApiBase: 'http://localhost:3000/',
  appInsights: {
    instrumentationKey: ''
  }
};
